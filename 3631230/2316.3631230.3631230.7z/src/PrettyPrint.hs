module PrettyPrint where

import Ast
import InferenceStructures
import Data.List ((\\), union, intercalate)
import qualified Data.Set as Set (toList)
import qualified Data.Map as Map (assocs)
import Data.Char (toLower)

instance Show Expr where
    show (Integer i) = show i
    show (Bool b) = map toLower $ show b
    show (Var var) = var
    show (Fun pi funcname arg e) = "mu" ++ funcname ++ "\\" ++ arg ++ "._{" ++ show pi ++ "} " ++ show e
    show (Fn pi arg e) = "\\" ++ arg ++ "._{" ++ show pi ++ "} " ++ show e
    show (App e1 e2) = show e1 ++ " " ++ show e2
    show (Let var e1 e2) = "let " ++ var ++ " = " ++ show e1 ++ " in " ++ show e2
    show (ITE c t f) = "if "++ show c ++ " then " ++ show t ++ " else " ++ show f
    show (Oper op e1 e2) = show e1 ++ " " ++ show op ++ " " ++ show e2
    show (Pair pi e1 e2) = "Pair_{" ++ show pi ++ "}(" ++ show e1 ++ "," ++ show e2 ++ ")"
    show (PCase e1 var1 var2 e2) = "pcase " ++ show e1 ++ " of Pair(" ++ show var1 ++ "," ++ show var2 ++ ") => " ++ show e2

instance Show Op where
    show (Add) = "+"
    show (Sub) = "-"
    show (Mul) = "*"
    show (Div) = "/"


instance Show Ty where
 show (TVar x) = x 
 show TyNat    = "Nat"
 show TyBool   = "Bool"
 show (TyFun t1 t2 ann) = "(" ++ show t1 ++ " -> " ++ show t2 ++ ") {ann: " ++ show ann ++ "}"
 show (TyPair t1 t2 ann) = "(" ++ show t1 ++ " , " ++ show t2 ++ ") {ann: " ++ show ann ++ "}"

instance Show Ann where
 show (AVar a) = a
 show (ASet set) = "{" ++ (intercalate "," (map show (Set.toList set))) ++ "}"
 show (AUnion a1 a2) = show a1 ++ " \\/ " ++ show a2

instance Show Constr where
 show Empty = "{}"
 show (Super var ann) = var ++ " >= " ++ show ann
 show (CUnion c1 c2) = show c1 ++ " \\/ " ++ show c2
 

instance Show Subst where
    show (Subs tysub annsub) = show tysub' ++ " --- " ++ show annsub' where
        tysub' = map (\(s, ty) -> s ++ " => " ++ show ty) (Map.assocs tysub)
        annsub' = map (\(s, ann) -> s ++ " => " ++ show ann) (Map.assocs annsub)