-- (C) 2013 Pepijn Kokke & Wout Elsinghorst
-- Adapted by Jurriaan Hage

{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE FlexibleContexts #-}
module Parsing where

import Ast

import Prelude hiding ( abs, sum )
import Data.Char (isSpace)
import Text.ParserCombinators.UU
import Text.ParserCombinators.UU.Utils
import Text.ParserCombinators.UU.Idioms (iI,Ii (..))
import Text.ParserCombinators.UU.BasicInstances (Parser,pSym)
import Control.Monad.State

-- * Top-Level Parsers

parseExpr :: String -> Expr
parseExpr = runParser "stdin" pExpr

-- * Parsing the FUN language
pExpr :: Parser Expr
pExpr = (pFn <|> pFun <|> pITE <|> pLet <|> pPair <|> pPCase {-<|> pCons <|> pNil <|> pLCase-}) <<|> pBin
  where
  
  -- literal expressions
  pLit = Integer <$> pInteger
     <|> Bool True  <$ pSymbol "true"
     <|> Bool False <$ pSymbol "false"
    
  -- atomic expressions
  pAtom = pLit
     <<|> Var <$> pIdent
     <<|> pParens pExpr
  
  -- simple expressions
  pFn,pFun,pLet,pITE,pPair :: Parser Expr
  pFn     = iI (Fn 0) "fn" pIdent "=>" pExpr Ii -- Default Pi to 0
  pFun    = iI (Fun 0) "fun" pIdent pIdent "=>" pExpr Ii -- Dito
  pLet    = iI Let "let" pIdent "=" pExpr "in" pExpr Ii
  pITE    = iI ITE "if" pExpr "then" pExpr "else" pExpr Ii
  pPair   = iI (Pair 0) "Pair(" pExpr "," pExpr ")" Ii
  pPCase  = iI PCase "pcase" pExpr "of Pair(" pIdent "," pIdent ") =>" pExpr Ii
  {-pCons   = iI (Cons 0) "Cons(" pExpr "," pExpr ")" Ii
  pNil    = iI (Nil 0) "Nil" Ii
  pLCase  = iI (LCase) "lcase" pExpr "of Cons(" pIdent "," pIdent ") => " pExpr Ii-}
   
  -- chained expressions
  pApp = pChainl_ng (App <$ pSpaces) pAtom
  pBin = pChainl_ng (bin <$> pOper) pApp
  
pIdent,pConst,pOper :: Parser Name
pIdent = lexeme $ (:) <$> pLower <*> pMany (pLetter <|> pDigit <|> pUnderscore)
pConst = lexeme $ (:) <$> pUpper <*> pMany (pLetter <|> pDigit <|> pUnderscore)
pOper  = lexeme $ pSome $ pAnySym "*+/-"

pUnderscore :: Parser Char
pUnderscore = pSym '_'

-- * Recognising more list structures with separators

pFoldr2Sep :: IsParser p => (a -> b -> b, b) -> p a1 -> p a -> p b
pFoldr2Sep alg@(op,e) sep p = must_be_non_empties "pFoldr2Sep" sep p pfm
  where pfm = op <$> p <*> pFoldr1 alg (sep *> p)

pList2Sep :: IsParser p => p a1 -> p a -> p [a]
pList2Sep s p = must_be_non_empties "pListSep" s p (pFoldr2Sep list_alg s p)




-- Tmp pi fix
fresh :: State Integer Integer
fresh = do
  n <- get
  _ <- put (n + 1)
  return n

labelE (Fun _ f x e) = do
  pi' <- fresh
  e'<- labelE e
  return (Fun pi' f x e')
labelE (Fn _ x e) = do
  pi' <- fresh
  e' <- labelE e
  return (Fn pi' x e')
labelE (Pair _ e1 e2) = do
  pi' <- fresh
  e1' <- labelE e1
  e2' <- labelE e2
  return (Pair pi' e1 e2)
labelE (App e1 e2) = do
    e1' <- labelE e1
    e2' <- labelE e2
    return (App e1' e2')
labelE (Let var e1 e2) = do
    e1' <- labelE e1
    e2' <- labelE e2
    return (Let var e1' e2')
labelE (ITE e1 e2 e3) = do
    e1' <- labelE e1
    e2' <- labelE e2
    e3' <- labelE e3
    return (ITE e1' e2' e3')
labelE (Oper op e1 e2) = do
    e1' <- labelE e1
    e2' <- labelE e2
    return (Oper op e1' e2')
labelE (PCase e1 var1 var2 e2) = do
    e1' <- labelE e1
    e2' <- labelE e2
    return (PCase e1' var1 var2 e2')
labelE other = return other

updateLabels :: Expr -> (Expr, Integer)
updateLabels e = runState (labelE e) 0