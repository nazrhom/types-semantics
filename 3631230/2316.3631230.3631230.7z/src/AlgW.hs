module AlgW where


import Ast
import Data.List (sort)
import qualified Data.Set as Set (Set, union, empty, singleton)
import qualified Data.Map as Map (Map, lookup, union, unions, singleton, lookup, empty)

import InferenceStructures
import PrettyPrint


------------------------------------------------------------------------------------------

ucfa :: Ty -> Ty -> Subst
ucfa TyNat TyNat = emptySubst
ucfa TyBool TyBool = emptySubst
ucfa (TyFun t1 t2 (AVar b1)) (TyFun t3 t4 (AVar b2)) =
    let
        th0    = Subs Map.empty (Map.singleton b2 (AVar b1))
        th1    = ucfa (applyth th0 t1) (applyth th0 t3)
        th2    = ucfa (applyth th1 $ applyth th0 t2) (applyth th1 $ applyth th0 t4)
    in
        thComp [th2, th1, th0]
ucfa (TyPair t1 t2 (AVar b1)) (TyPair t3 t4 (AVar b2)) =
    let
        th0     = Subs Map.empty (Map.singleton b2 (AVar b1))
        th1     = ucfa (th0 `applyth` t1) (th0 `applyth` t3)
        th2     = ucfa (th1 `applyth` (th0 `applyth` t2)) (th1 `applyth` (th0 `applyth` t4))
    in
        thComp [th2, th1, th0]
ucfa t (TVar a) | t == TVar a        = Subs (Map.singleton a t) Map.empty
                | not $ contains a t = Subs (Map.singleton a t) Map.empty
                | otherwise          = error $ "Fail in unification, type variable " ++ a ++ 
                                                "occurs in " ++ show t
ucfa x@(TVar _) t = ucfa t x
ucfa t1 t2 = error $ "Fail in unification, tried to unify " ++ show t1 ++ " and " ++ show t2


-- List of pi's to generate fresh
wcfa :: Context -> Expr -> ([Int], [Int]) -> (Ty, Subst, Constr, ([Int], [Int]))
wcfa _ (Integer _) fresh = (TyNat , emptySubst, Empty, fresh)
wcfa _ (Bool _)   fresh = (TyBool, emptySubst, Empty, fresh)
wcfa gam (Var x) fresh = case lookup x gam of
                        Just b  -> (b, emptySubst, Empty, fresh)
                        Nothing -> error $ "Variable " ++ show x ++ " not found in context"
wcfa gam (Fun pi func var tm) (tvs0 : tvs1 : tvss, avs) = 
                                    let ax = TVar $ "a" ++ show tvs0
                                        a0 = TVar $ "a" ++ show tvs1
                                        b0 = AVar $ "b" ++ show (head avs)
                                        functype = TyFun ax a0 b0
                                        gam' = (func, functype) : (var, ax) : gam
                                        (t0, th0, c0, (tvs', avs')) = wcfa gam' tm (tvss, tail avs)
                                        th1 = ucfa t0 (th0 `applyth` a0)
                                        t1 = TyFun (th1 `applyth` (th0 `applyth` ax)) (th1 `applyth` t0) (th1 `applytha` (th0 `applytha` b0))
                                        (AVar bsup) = (th1 `applytha` (th0 `applytha` b0))
                                        c1 = CUnion (th1 `applythc` c0) (Super bsup (ASet $ Set.singleton pi))
                                     in (t1
                                        , thComp [th1, th0]
                                        , c1
                                        , (tvs', avs') 
                                        )
wcfa gam (Fn pi var tm) (tvs, avs) = let a0 = TVar $ "a" ++ show (head tvs)
                                         (t0, th0, c0, (tvs', avs')) = wcfa ((var, a0):gam) tm (tail tvs, avs)
                                         b0 = "b" ++ show (head avs')
                                     in (TyFun (th0 `applyth` a0) t0 (AVar b0)
                                        , th0
                                        , CUnion c0 (Super b0 (ASet $ Set.singleton pi))
                                        , (tvs', tail avs') 
                                        )

wcfa gam (App tm1 tm2) fresh = let (t1, th1, c1, fresh1) = wcfa gam tm1 fresh
                                   (t2, th2, c2, (tvs2, avs2)) = wcfa (th1 `applythg` gam) tm2 fresh1
                                   a = TVar $ "a" ++ show (head tvs2)
                                   b = AVar $ "b" ++ show (head avs2)
                                   th3 = ucfa (th2 `applyth` t1) (TyFun t2 a b)
                               in (th3 `applyth` a
                                  , thComp [th3, th2, th1] 
                                  , CUnion (th3 `applythc` (th2 `applythc` c1)) (th3 `applythc` c2)
                                  , (tail tvs2, tail avs2)
                                  )

wcfa gam (ITE tm0 tm1 tm2) fresh = let (t0, th0, c0, fresh0) = wcfa gam tm0 fresh
                                       (t1, th1, c1, fresh1) = wcfa (th0 `applythg` gam) tm1 fresh0
                                       (t2, th2, c2, fresh2) = wcfa (th1 `applythg` (th0 `applythg` gam)) tm2 fresh1
                                       th3 = ucfa (th2 `applyth` (th1 `applyth` t0)) TyBool
                                       th4 = ucfa (th3 `applyth` t2) (th3 `applyth` (th2 `applyth` t1))
                                       cp0 = th4 `applythc` (th3 `applythc` (th2 `applythc` (th1 `applythc` c0)))
                                       cp1 = th4 `applythc` (th3 `applythc` (th2 `applythc` c1))
                                       cp2 = th4 `applythc` (th3 `applythc` c2)
                                  in (th4 `applyth` (th3 `applyth` t2)
                                        , thComp [th4, th3, th2, th1, th0]
                                        , CUnion cp0 (CUnion cp1 cp2)
                                        , fresh2
                                        )

wcfa gam (Let var tm1 tm2) fresh = let (t1, th1, c1, fresh1) = wcfa gam tm1 fresh
                                       (t2, th2, c2, fresh2) = wcfa ((var, t1) : (th1 `applythg` gam)) tm2 fresh1
                                   in ( t2
                                      , thComp [th2, th1]
                                      , CUnion (th2 `applythc` c1) c2
                                      , fresh2
                                      )
wcfa gam (Oper op tm1 tm2) fresh = let (t1, th1, c1, fresh1) = wcfa gam tm1 fresh
                                       (t2, th2, c2, fresh2) = wcfa (th1 `applythg` gam) tm2 fresh1
                                       (opT1, opT2, opResT) = opToTy op
                                       th3 = ucfa (th2 `applyth` t1) opT1
                                       th4 = ucfa (th3 `applyth` t2) opT2
                                 in ( opResT
                                    , thComp [th4, th3, th2, th1]
                                    , CUnion (applythc th4 $ applythc th3 $ applythc th2 c1)
                                             (applythc th4 $ applythc th3 c2)
                                    , fresh2
                                    )
wcfa gam (Pair pi tm1 tm2) fresh = let
                                        (t1, th1, c1, fresh1)   = wcfa gam tm1 fresh
                                        (t2, th2, c2, (tvs2, avs2)) = wcfa (th1 `applythg` gam) tm2 fresh1
                                        b0 = AVar $ "b" ++ show (head avs2)
                                        in
                                            ( TyPair t1 t2 b0
                                            , thComp [th2, th1]
                                            , CUnion (undefined) (undefined)
                                            , (tvs2, tail avs2)
                                            )
wcfa gam (PCase tm1 var1 var2 tm2) fresh = let
                                            (TyPair t1 t2 b1, th1, c1, fresh1) = wcfa gam tm1 fresh
                                            gam' = (var1, t1) : (var2, t2) : gam
                                            (t3, th2, c2, fresh2) = wcfa gam' tm2 fresh1
                                           in
                                            ( t3
                                            , thComp [th2, th1]
                                            , CUnion (undefined) (undefined)
                                            , fresh2
                                            )

-- type substitution
applyth :: Subst -> Ty -> Ty
applyth _ TyNat = TyNat
applyth _ TyBool = TyBool
applyth th (TyFun t1 t2 b) = TyFun (applyth th t1) (applyth th t2) (applytha th b)
applyth th (TyPair t1 t2 b) = TyPair (applyth th t1) (applyth th t2) (applytha th b)
applyth s@(Subs m _) t@(TVar a) = applyth' s t traverse 
                                    where traverse = False
-- Slightly different version, which keeps traversing
applyth' :: Subst -> Ty -> Bool -> Ty
applyth' s@(Subs m _) (TVar a) traverse = case Map.lookup a m of
                                    (Just t@(TVar a')) -> 
                                        if traverse then applyth' s t traverse else t
                                    Just t -> t
                                    Nothing -> TVar a

-- annotation substitution
applytha :: Subst -> Ann -> Ann
applytha s@(Subs _ m) a@(AVar b) = applytha' s a traverse
                                    where traverse = False
applytha th (AUnion a1 a2) = AUnion (applytha th a1) (applytha th a2)
applytha _  a = a
-- Slightly different version, which keeps traversing
applytha' :: Subst -> Ann -> Bool -> Ann
applytha' s@(Subs _ m) (AVar b) traverse = case Map.lookup b m of
                                    (Just a@(AVar b')) -> 
                                        if traverse then applytha' s a traverse else a
                                    Just a -> a
                                    Nothing -> AVar b 

-- applying an annotation substitution to a constraint
applythc :: Subst -> Constr -> Constr
applythc th (CUnion c1 c2) = CUnion (applythc th c1) (applythc th c2)
applythc th@(Subs _ m) (Super b a)    = Super b' (applytha th a)
            where b' = case Map.lookup b m of
                        Just (AVar x) -> x
                        Nothing       -> b
                        _             -> error "Expected an AVar x, but got something else"
applythc _ Empty = Empty         

applythg :: Subst -> Context -> Context
applythg (Subs tvs _) gam = map f gam where
        f :: (Name, Ty) -> (Name, Ty)
        f (var, t@(TVar tvar)) = case Map.lookup tvar tvs of
            Just t' -> (var, t')
            Nothing -> (var, t)
        f mapping = mapping
--applythg' (Subs tvs _) gam = undefined

-- checks if the type variable a occurs in type t
contains :: TyVar -> Ty -> Bool
contains a (TVar t) = a == t
contains a (TyFun t1 t2 _) = contains a t1 || contains a t2
contains _ _ = False 

emptySubst :: Subst
emptySubst = Subs Map.empty Map.empty

thComp :: [Subst] -> Subst
thComp thetas = Subs (Map.unions tthetas) (Map.unions athetas) where
    tthetas = map (\(Subs a _) -> a) thetas
    athetas = map (\(Subs _ b) -> b) thetas

opToTy :: Op -> (Ty, Ty, Ty)
opToTy _ = (TyNat, TyNat, TyNat)