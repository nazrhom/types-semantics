-- (C) 2013-14 Pepijn Kokke & Wout Elsinghorst
-- Modifications made Jurriaan Hage

module Main
  ( module Ast
  , module Parsing 
  , main
  ) where

import Ast
import Parsing
import PrettyPrint
import Data.Set (Set)
import Data.Map (Map)
import InferenceStructures
import AlgW
  

 
run :: String -> IO ()   
run name = do
    p <- parse name
    let (p', _) = updateLabels p
    putStrLn (name ++ ".fun")
    putStrLn ("Src: " ++ show p')
    let res = wcfa [] p' ([0..], [0..])
    showResult res

showResult :: (Ty, Subst, Constr, ([Int], [Int])) -> IO ()
showResult (ty, subst, _, _) = do
    putStrLn ("Ty: " ++ show ty)
    putStrLn ("Subs: " ++ show subst)
    putStrLn "\n"


-- |Parse and label program
parse :: String -> IO Expr
parse programName = do
    let fileName = "examples\\" ++  programName ++".fun"
    content <- readFile fileName
    return (parseExpr content)

  
main :: IO ()
main = do
    let progs = ["boollit", "intlit", "ite", "var", "fn1", "app", "fun", "pair1", "pair2"]
    mapM_ run progs
    let crashes = ["debug", "itewrong" {- , "parseproblem"-}]
    --mapM_ run crashes
    return ()