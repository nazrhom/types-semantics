module InferenceStructures where

import Ast
import Data.List (sort)

import qualified Data.Set as Set (Set, union, empty)
import qualified Data.Map as Map (Map, lookup, union, unions, singleton, lookup, empty)

type AnnVar = String    
type TyVar  = String


data Ty = TyNat
        | TyBool
        | TyFun Ty Ty Ann
        | TVar TyVar 
        | TyPair Ty Ty Ann
        deriving Eq
-- | TyTup Ty Ty --Ann
-- | TyList Ty Ann 

type Context = [(Name, Ty)]

data Ann = ASet (Set.Set Pi) 
            | AUnion Ann Ann  
            | AVar AnnVar

instance Eq Ann where
 a1 == a2 = let (s1, bs1) = simplAnn a1
                (s2, bs2) = simplAnn a2
            in s1 == s2 && bs1 == sort bs2

data Constr = Empty 
                | Super AnnVar Ann 
                | CUnion Constr Constr


-- Chosen was to represent theta as a tuple for both types and annotations.
-- This gives easier application of theta's.
type TySub = Map.Map String Ty
type AnnSub = Map.Map String Ann

data Subst = Subs TySub AnnSub --(Map String Ty) (Map String Ann)


--------------------------
simplAnn :: Ann -> (Set.Set Pi, [AnnVar])
simplAnn (AUnion a1 a2) = let
    (s1, vs1) = simplAnn a1
    (s2, vs2) = simplAnn a2
    in (Set.union s1 s2, sort $ vs1 ++ vs2)
simplAnn (AVar b) = (Set.empty, [b])
simplAnn (ASet s) = (s, [])
