module ConstraintSolver where

import qualified Data.Map as M
import qualified Data.Set as S
import Data.Maybe

import Definitions

type WorkList = [ConstrU]
type Flow = [ConstrU]

solve :: AnnVar -> Constr -> S.Set Integer
solve b c =
    let flow = S.toList c
        annvars = allAnnVarsConstr c `S.union` S.singleton b
        initEnv = foldr (\x y -> M.singleton x S.empty `M.union` y) M.empty annvars
        env = fixpoint initEnv flow flow
    in case M.lookup b env of
            Just s -> s
            Nothing -> error $ show b ++ "  " ++ show env

--Maximal fixpoint algorithm
fixpoint :: M.Map AnnVar (S.Set Integer) -> WorkList -> Flow -> M.Map AnnVar (S.Set Integer)
fixpoint env w f =
    let (Sup b ann) = head w --Get the head of the worklist
        t =  tail w
    in 
    if not $ null w
        then 
        if containsConstr env b ann --If the annvar b contains the constraints of ann
            then
                fixpoint env t f --Then we are done with b and continue with the rest of the worklist
            else
                let ppoints = programPoints env ann --Find the program points of ann
                    env' = updateSet env b ppoints --Insert these into the program points of b
                    w' = updateWorkList w f b --Add all constraints that contain b
                in fixpoint env' w' f --Redo the fixpoint
    else
        env


containsConstr :: M.Map AnnVar (S.Set Integer) -> AnnVar -> Ann -> Bool
containsConstr env b ann =
    let ppoints1 = programPoints env ann
        ppoints2 = 
            case M.lookup b env of
                Just s -> s
                Nothing -> error $ show b ++ "  " ++ show env
    in ppoints1 `S.isSubsetOf` ppoints2

programPoints :: M.Map AnnVar (S.Set Integer) -> Ann -> S.Set Integer
programPoints env ann =
    S.foldr (\x y -> 
        let pp = programPoints' env x
        in pp `S.union` y
        ) S.empty ann

programPoints' :: M.Map AnnVar (S.Set Integer) -> AnnU -> S.Set Integer
programPoints' env (AVar annvar) = fromJust $ M.lookup annvar env
programPoints' env (Single p) = S.singleton p

updateSet :: M.Map AnnVar (S.Set Integer) -> AnnVar -> S.Set Integer -> M.Map AnnVar (S.Set Integer)
updateSet env b ppoints = M.adjust (S.union ppoints) b env

updateWorkList :: WorkList -> Flow -> AnnVar -> WorkList
updateWorkList w [] b = w
updateWorkList w (cu:f) b
    | containsAnn cu b = updateWorkList (cu:w) f b
    | otherwise = updateWorkList w f b

containsAnn :: ConstrU -> AnnVar -> Bool
containsAnn (Sup annvar ann) b = 
    annvar == b || containsAnn' ann b

containsAnn' :: Ann -> AnnVar -> Bool
containsAnn' ann b =
    foldr (\x y -> containsAnn'' x b || y) False ann

containsAnn'' :: AnnU -> AnnVar -> Bool
containsAnn'' (AVar annvar) b = annvar == b
containsAnn'' _ _ = False

allAnnVarsConstr :: Constr -> S.Set AnnVar
allAnnVarsConstr c = S.foldr (\x y -> allAnnVarsConstrU x `S.union` y) S.empty c

allAnnVarsConstrU :: ConstrU -> S.Set AnnVar
allAnnVarsConstrU (Sup b ann) = S.singleton b `S.union` allAnnVarsAnn ann

allAnnVarsAnn :: Ann -> S.Set AnnVar
allAnnVarsAnn ann = foldr (\x y -> allAnnVarsAnnU x `S.union` y) S.empty ann

allAnnVarsAnnU :: AnnU -> S.Set AnnVar
allAnnVarsAnnU (AVar annvar) = S.singleton annvar
allAnnVarsAnnU _ = S.empty