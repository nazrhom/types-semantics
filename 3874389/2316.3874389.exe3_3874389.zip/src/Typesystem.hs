module Typesystem where

import Data.Map as M
import Data.Set as S
import Data.List as L
import Data.Maybe
import Control.Monad
import Debug.Trace

import View
import ConstraintSolver
import Definitions
import Ast

typecheck :: Expr -> IO ()
typecheck e = do
    (_, e') <- return $ assignProgramPoints (1, e)
    (_, _, ty_env, ty, subst, c) <- w_ul (1, 1, M.empty, M.empty, e')
    
    putStrLn ""
    putStrLn "-----------------------------------"
    putStrLn "OUTPUT:"
    let ty' = solveConstraints ty c
    putStrLn $ show ty'
    
    solveConstraintsEnv ty_env c

solveConstraintsEnv :: TyEnv -> Constr -> IO ()
solveConstraintsEnv ty_env c = do
    let keys = M.keys ty_env
    mapM_ (\x -> 
        let ty = case fromJust $ M.lookup x ty_env of
                    Type t -> t
                    ForAll _ t -> t
        in do 
            putStr (x ++ " : ") 
            putStrLn $ show $ solveConstraints ty c) keys

solveConstraints :: Ty -> Constr -> Ty
solveConstraints (Func ann t1 t2) c =
    let t1' = solveConstraints t1 c
        t2' = solveConstraints t2 c
    in  view (Func ann t1' t2') (solve ann c)
solveConstraints (TPair ann t1 t2) c =
    let t1' = solveConstraints t1 c
        t2' = solveConstraints t2 c
    in view (TPair ann t1' t2') (solve ann c)
solveConstraints (TList annS t) c =
    let t' = solveConstraints t c
        ppoints = S.foldr (\x y -> solve x c `S.union` y) S.empty annS
    in view (TList annS t') ppoints
solveConstraints t c = t

--generates a forall over all unbound type variables
generalize :: (TyEnv, Ty) -> TyScheme
generalize (env, t) = 
    let vars = S.toList $ freeVarsTy t `S.difference` freeVarsEnv env
    in if L.null vars
        then Type t
        else ForAll vars t

--Removes a Forall and substitutes the type variables that it contained
--with fresh ones.
instantiate :: (Integer, TyScheme) -> (Integer, Ty)
instantiate (n, ForAll vars t) = 
    L.foldr (\x y ->
        let (n1, ty) = y  
            (n2, freshvar) = freshTyVar n1
        in (n2, substituteWith x freshvar ty)) (n, t) vars
instantiate (n, Type t) = (n, t)

--The unification algorithm. First of all it requires two given
--types to be of the same type. Any subtypes should also be of the same
--type. Also the annotation variables are mapped to one another.

--Note that the inference and unification algorithm are in IO purely for debugging purposes
u_cfa :: (Integer, Ty, Ty) -> IO (Integer, Subst, Constr)
u_cfa (m, Nat, Nat) = return (m, Subst M.empty M.empty, S.empty)
u_cfa (m, Boolean, Boolean) = return (m, Subst M.empty M.empty, S.empty)
u_cfa (m, TPair ann1 t1 t2, TPair ann2 t3 t4) = do
    let (m1, annvar) = freshAnnVar m
        subst0 = Subst M.empty (M.singleton ann1 ann2)
        tsub0 = substTy subst0
    (m2, subst1, c1) <- u_cfa (m1, tsub0 t1, tsub0 t3)
    (m3, subst2, c2) <- u_cfa (m2, substTy subst1 $ tsub0 t2, substTy subst1 $ tsub0 t4)
    let c2' = substConstr subst1 c1
    return (m3, subst2 `pointSubst` subst1 `pointSubst` subst0, c1 `S.union` c2')       
u_cfa (m, Func ann1 t1 t2, Func ann2 t3 t4) = do
    let (m1, annvar) = freshAnnVar m
        subst0 = Subst M.empty (M.singleton ann1 annvar)
        
        c1 = S.singleton (Sup annvar (S.singleton $ AVar ann1))
        c2 = S.singleton (Sup ann1 (S.singleton $ AVar ann2))
        tsub0 = substTy subst0
    (m2, subst1, c3) <- u_cfa (m1, tsub0 t1, tsub0 t3)
    (m3, subst2, c4) <- u_cfa (m2, substTy subst1 $ tsub0 t2, substTy subst1 $ tsub0 t4)
    let c1' = substConstr subst2 (substConstr subst1 c1)
        c2' = substConstr subst2 (substConstr subst1 c2)
    return (m3, subst2 `pointSubst` subst1 `pointSubst` subst0, c1' `S.union` c2' `S.union` c3 `S.union` c4)
u_cfa (m, TList annS1 t1, TList annS2 t2) = do
    (m1, subst1, c1) <- u_cfa (m, t1, t2)
    return (m1, subst1, c1)
u_cfa (m, TVar v, t) =
    if chk (TVar v, t)
        then return (m, Subst (M.singleton v t) M.empty, S.empty)
        else error "failure in unification"
u_cfa (m, t, TVar v) =
    if chk (TVar v, t)
        then return (m, Subst (M.singleton v t) M.empty, S.empty)
        else error "failure in unification"
u_cfa (_, t1,t2) = error $ "Could not unify type " ++ show t1 ++ " with type " ++ show t2

--We need a second type of unification to handle how unification should
--be done depending on the expression we are trying to infer the type of
--This type of unification is mostly expressions with multiple branches that
--should be of equal type.
--In this unification function we generate a fresh annotation variable and then
--map the existing annotation variables to it. Furthermore we now want to generate constraints
--that specify that the fresh annotation variable is under constraint of the old ones. 
u_cfa_Br :: (Integer, Ty, Ty) -> IO (Integer, Subst, Constr)
u_cfa_Br (m, Nat, Nat) = return (m, Subst M.empty M.empty, S.empty)
u_cfa_Br (m, Boolean, Boolean) = return (m, Subst M.empty M.empty, S.empty)
u_cfa_Br (m, Func ann1 t1 t2, Func ann2 t3 t4) = do
    let (m1, annvar) = freshAnnVar m
        subst0 = Subst M.empty (M.singleton ann2 annvar `M.union` M.singleton ann1 annvar)
        
        c1 = S.singleton (Sup annvar (S.singleton $ AVar ann1))
        c2 = S.singleton (Sup annvar (S.singleton $ AVar ann2))
        tsub0 = substTy subst0
    (m2, subst1, c3) <- u_cfa_Br (m1, tsub0 t1, tsub0 t3)
    (m3, subst2, c4) <- u_cfa_Br (m2, substTy subst1 $ tsub0 t2, substTy subst1 $ tsub0 t4)
    let c1' = substConstr subst2 (substConstr subst1 c1)
        c2' = substConstr subst2 (substConstr subst1 c2)
    return (m3, subst2 `pointSubst` subst1 `pointSubst` subst0, c1' `S.union` c2' `S.union` c3 `S.union` c4)
u_cfa_Br (m, TPair ann1 t1 t2, TPair ann2 t3 t4) = do
    let (m1, annvar) = freshAnnVar m
        subst0 = Subst M.empty (M.singleton ann2 annvar `M.union` M.singleton ann1 annvar)
        c1 = S.singleton (Sup annvar (S.singleton $ AVar ann1))
        c2 = S.singleton (Sup annvar (S.singleton $ AVar ann2))
        tsub0 = substTy subst0
    (m2, subst1, c3) <- u_cfa_Br (m1, tsub0 t1, tsub0 t3)
    (m3, subst2, c4) <- u_cfa_Br (m2, substTy subst1 $ tsub0 t2, substTy subst1 $ tsub0 t4)
    let c1' = substConstr subst2 (substConstr subst1 c1)
        c2' = substConstr subst2 (substConstr subst1 c2)
    return (m3, subst2 `pointSubst` subst1 `pointSubst` subst0, c1' `S.union` c2' `S.union` c3 `S.union` c4)
u_cfa_Br (m, TList annS1 t1, TList annS2 t2) = do
    let (m1, b) = freshAnnVar m
        ann1Subs = S.foldr (\x y -> M.singleton x b `M.union` y) M.empty annS1
        ann2Subs = S.foldr (\x y -> M.singleton x b `M.union` y) M.empty annS2
        subst0 = Subst M.empty (M.union ann1Subs ann2Subs)
        constrs = S.singleton (Sup b (S.map AVar annS1 `S.union` S.map AVar annS2))
    (m1, subst1, c3) <- u_cfa_Br(m, t1, t2)
    let constrs' = substConstr subst1 constrs
    return (m1, subst1 `pointSubst` subst0, c3 `S.union` constrs')
u_cfa_Br (m, TVar v, t) =
    if chk (TVar v, t)
        then return (m, Subst (M.singleton v t) M.empty, S.empty)
        else error "failure in unification"
u_cfa_Br (m, t, TVar v) =
    if chk (TVar v, t)
        then return (m, Subst (M.singleton v t) M.empty, S.empty)
        else error "failure in unification"
u_cfa_Br (_, t1,t2) = error $ "Could not unify type " ++ show t1 ++ " with type " ++ show t2


chk :: (Ty, Ty) -> Bool
chk (TVar v, t) = 
    let freevars = show $ freeVarsTy t
        t' = show t
    in not $ (TVar v) /= t && S.member v (freeVarsTy t)


--Inference algorithm. This is the main algorithm of the typesystem and does most of the work.
--Together with the unification algorithm types and annotation variables are correctly determined.
w_ul :: (Integer, Integer, TyEnv, ConstrEnv, Expr) -> IO (Integer, Integer, TyEnv, Ty, Subst, Constr)
w_ul (n, m, ty_env, c_env, Integer _) = return (n, m, ty_env, Nat, Subst M.empty M.empty, S.empty)
w_ul (n, m, ty_env, c_env, Bool b) = return (n, m, ty_env, Boolean, Subst M.empty M.empty, S.empty)
w_ul (n, m, ty_env, c_env, Var x) = 
    let v = M.lookup x ty_env
    in case v of --Now that we need the type of this variable, we would like
                 --to give it an actual type
        Just k -> let (n', k') = instantiate (n, k)
                  in
                  --If we remembered a constraint then we can give it back
                  case M.lookup x c_env of 
                    Just c -> return (n', m, ty_env, k', Subst M.empty M.empty, c)
                    Nothing -> return (n', m, ty_env, k', Subst M.empty M.empty, S.empty)
        Nothing -> error $ show x ++ "  \n" ++ show ty_env
w_ul (n, m, ty_env, c_env, Fn p x e) = do
    let (n1, a) = freshTyVar n
    --We do not know the type of x, so we create a fresh type
    --variable and then insert the binding into the type environment
        env' = M.insert x (Type (TVar a)) ty_env
    --Then we can simply determine the type of the expression
    (n2, m1, ty_env', ety, subst, c) <- w_ul (n1, m, env', c_env, e)
    --We then no longer need the binding of x
    let ty_env_delx = M.delete x ty_env'
        (m2, b) = freshAnnVar m1

    return (n2, m2, ty_env_delx, Func b (substTyAnn subst $ substTyVar subst a) ety, subst, c `S.union` S.singleton (Sup b (S.singleton $ Single p)))
w_ul (n, m, ty_env, c_env, Fun p f x e) = do
    let (n1, a1) = freshTyVar n
        (n2, a2) = freshTyVar n1
        (m1, b1) = freshAnnVar m
    --We don't know what the type of f and x are, but we do need to know about them
    --So we insert them into the type environment
        ty_env1 = M.insert f (Type $ Func b1 (TVar a1) (TVar a2)) ty_env
        ty_env2 = M.insert x (Type $ TVar a1) ty_env1
    --After inferring the type of the expression, we can determine what the type of the result
    --of f should be.
    (n3, m2, ty_env3, ety, subst1, c1) <- w_ul (n2, m1, ty_env2, c_env, e)
    (m3, subst2, c2) <- u_cfa(m2, ety, substTyAnn subst1 $ substTy subst1 (TVar a2))
    --We might have also been able to determine the type of the argument of f
    let b1' = substAnnVar subst2 $ substAnnVar subst1 b1
        a1' = substTyAnn subst2 $ substTy subst2 $ substTyAnn subst1 $ substTyVar subst1 a1
        ety' = substTyAnn subst2 $ substTy subst2 ety
    --We do not need both f and x in the type environment anymore
        ty_env_delfx = M.delete x (M.delete f ty_env3)
        ty_env_delfx' = substEnv subst2 ty_env_delfx
        c1' = substConstr subst2 c1
        c2 = S.singleton $ Sup b1' (S.singleton $ Single p)
    return (n3,m3, ty_env_delfx', Func b1' a1' ety, subst2 `pointSubst` subst1, c1' `S.union` c2)
w_ul (n, m, ty_env, c_env, App e1 e2) = do
    --First determine the types of both expressions
    (n1, m1, ty_env1, e1ty, subst1, c1) <- w_ul (n, m, ty_env, c_env, e1)
    (n2, m2, ty_env2, e2ty, subst2, c2) <- w_ul (n1, m1, substEnv subst1 ty_env, c_env, e2)
    let (n3, a) = freshTyVar n2
        (m3, b) = freshAnnVar m2
    --Do a unification. We know that the first expression must be a function that takes
    --an argument of the type of the second expression
    (m4, subst3, c3) <- u_cfa (m3, substTyAnn subst2 $ substTy subst2 e1ty, Func b e2ty (TVar a))
    let ty_env3 = substEnv (subst3 `pointSubst` subst2 `pointSubst` subst1) (M.union ty_env2 ty_env1)

    return (n3, m4, ty_env3, substTyAnn subst3 $ substTyVar subst3 a, subst3 `pointSubst` subst2 `pointSubst` subst1,
        (substConstr subst3 (substConstr subst2 c1))
        `S.union`
        (substConstr subst3 c2)
        `S.union`
        c3)
w_ul (n, m, ty_env, c_env, Let x e1 e2) = do
    --Determine the type of the binding
    (n1, m1, ty_env1, e1ty, subst1, c1) <- w_ul (n, m, ty_env, c_env, e1)

    --Generalize this type and insert it into the type environment
    --Furthermore we would like to remember the constraints of this type
    --that way we can always use this variable fresh without risking any kind of poisoning
    let ty_env_s1 = substEnv subst1 ty_env
        ty_env_s1' = M.insert x (generalize (ty_env_s1, e1ty)) ty_env_s1 --Insert the type into the ty_env
        c_env2 = M.insert x c1 c_env
    --pass the updated type environment to determine the type of the body
    (n2, m2, ty_env2, e2ty, subst2, c2) <- w_ul (n1, m1, ty_env_s1', c_env2, e2)

    let ty_env3 = M.union ty_env2 ty_env1

    return (n2, m2, ty_env3, e2ty, subst2 `pointSubst` subst1, substConstr subst1 c1 `S.union` c2 `S.union` c1)
w_ul (n, m, ty_env, c_env, ITE e0 e1 e2) = do
    --First we simply determine the types of the expressions
    (n0, m0, ty_env1, e0ty, subst0, c0) <- w_ul (n, m, ty_env, c_env, e0)
    (n1, m1, ty_env2, e1ty, subst1, c1) <- w_ul(n0, m0, substEnv subst0 ty_env, c_env, e1)
    (n2, m2, ty_env3, e2ty, subst2, c2) <- w_ul(n1, m1, substEnv subst1 (substEnv subst0 ty_env), c_env, e2)

    --The condition expression must be of type bool
    (m3, subst3, c3) <- u_cfa (m2, substTyAnn subst2 $ substTy subst2 (substTyAnn subst1 $ substTy subst1 e0ty), Boolean)
    --The branches should also be of equal type
    (m4, subst4, c4) <- u_cfa_Br (m3, substTyAnn subst3 $ substTy subst3 (substTyAnn subst2 $ substTy subst2 e1ty), substTyAnn subst3 $ substTy subst3 e2ty)

    --Note that we don't apply the substitution of unification to the returning type environment to prevent poisoning
    return (n2, m4, ty_env3, substTyAnn subst4 (substTyAnn subst3 (substTy subst4 (substTy subst3 e2ty))), 
        subst3 `pointSubst` 
        subst2 `pointSubst` subst1 `pointSubst`
        subst0,
        substConstr subst4 (
            substConstr subst3 (
                substConstr subst2 (
                    substConstr subst1 c0)))
        `S.union`
        substConstr subst4 (
            substConstr subst3 (
                substConstr subst2 c1))
        `S.union`
        substConstr subst4 (
            substConstr subst3 c2)
        `S.union`
        substConstr subst4 c3
        `S.union`
        c4)
w_ul (n, m, ty_env, c_env, Oper op e1 e2) = do
    --Determine the types of the operands
    (n1, m1, ty_env1, e1ty, subst1, c1) <- w_ul (n, m, ty_env, c_env, e1)
    (n2, m2, ty_env2, e2ty, subst2, c2) <- w_ul (n1, m1, substEnv subst1 ty_env, c_env, e2)
    --Given that we only have binary operators on integers, we only need to check that
    --the expressions unify with Nat
    (m3, subst3, c3) <- u_cfa_Br (m2, substTyAnn subst2 $ substTy subst2 e1ty, Nat)
    (m4, subst4, c4) <- u_cfa_Br (m3, substTyAnn subst3 $ substTy subst3 e2ty, Nat)

    let all_subst = subst4 `pointSubst` subst3 `pointSubst` subst2 `pointSubst` subst1
        all_constr = (substConstr subst4 $
                        substConstr subst3 $
                            substConstr subst2 c1)
                    `S.union`
                    (substConstr subst4 $
                        substConstr subst3 c2)
                    `S.union`
                    substConstr subst4 c3
                    `S.union`
                    c4
        ty_env3 = M.union ty_env2 ty_env1
    
    --The result will always be of type Nat
    return (n2, m4, ty_env3, Nat, all_subst, all_constr)
-------------PAIRS--------------------------------
w_ul (n, m, ty_env, c_env, Pair pi e1 e2) = do
    (n1, m1, ty_env1, e1ty, subst1, c1) <- w_ul (n, m, ty_env, c_env, e1)
    (n2, m2, ty_env2, e2ty, subst2, c2) <- w_ul (n1, m1, substEnv subst1 ty_env, c_env, e2)
    let (m3, b) = freshAnnVar m2
        ty_env3 = M.union ty_env2 ty_env1
    return (n2, m3, ty_env3, TPair b (substTyAnn subst2 e1ty) (substTyAnn subst1 e2ty), subst2 `pointSubst` subst1,
        (substConstr subst2 c1) `S.union` c2 `S.union` (S.singleton $ Sup b (S.singleton $ Single pi)))
w_ul (n, m, ty_env, c_env, PCase e1 x1 x2 e2) = do
    --First we have to determine the type of the expression we are casing on
    (n1, m1, ty_env1, e1ty, subst1, c1) <- w_ul (n, m, ty_env, c_env, e1)
    let (n2, a1) = freshTyVar n1
        (n3, a2) = freshTyVar n2
        (m2, b1) = freshAnnVar m1
        ty_env2 = M.insert x1 (Type (TVar a1)) ty_env
        ty_env3 = M.insert x2 (Type (TVar a2)) ty_env2
    --We have to ensure that e1 is Pair type
    --By doing so we also learn the types of its components
    (m3, subst2, c2) <- u_cfa_Br (m2, e1ty, TPair b1 (TVar a1) (TVar a2))
    --We can now infer the type of the body
    (n4, m4, ty_env4, e2ty, subst3, c3) <- w_ul (n3, m3, substEnv subst2 (substEnv subst1 ty_env3), c_env, e2)
    --We no longer need the bindings and we therefore remove them
    let ty_env5 = M.delete x1 $ M.delete x2 $ M.union ty_env4 ty_env3 
    return $ 
        (n4, m4, ty_env5, e2ty, subst3 `pointSubst` subst2 `pointSubst` subst1,
            (substConstr subst3 $
                substConstr subst2 c1)
            `S.union`
            substConstr subst3 c2
            `S.union`
            c3)
------------------LISTS------------------------------
w_ul (n, m, ty_env, c_env, Nil p) = do
    let (m1, b) = freshAnnVar m
        (n1, a) = freshTyVar n
        c = S.singleton $ Sup b (S.singleton $ Single p)
    return (n1, m1, ty_env, TList (S.singleton b) (TVar a), Subst M.empty M.empty, c)
w_ul (n, m, ty_env, c_env, Cons p e l) = do
    let (m1, b) = freshAnnVar m
    --Determine the types of the elements of the list and of the tail of this list
    (n1, m2, ty_env1, ety, subst1, c1) <- w_ul (n, m1, ty_env, c_env, e)
    (n2, m3, ty_env2, lty, subst2, c2) <- w_ul (n1, m2, substEnv subst1 ty_env, c_env, l)
    let 
        lty' = substTy subst2 lty
        ety' = substTy subst2 ety
        (n3, a1) = freshTyVar n2
        (n4, a2) = freshTyVar n3
        (m4, b1) = freshAnnVar m3
    --The tail should be a list and should contain elements of the same type as ety
    (m5, _, _) <- u_cfa_Br (m4, TList (S.singleton b) ety', lty')
    let (TList annS t) = lty'
        ty_env3 = M.union ty_env1 ty_env2
        c4 = S.singleton $ Sup b (S.singleton $ Single p)
    return (n4, m5, ty_env3, TList (S.insert b annS) ety', subst2 `pointSubst` subst1,
            c4
            `S.union`
            c1
            `S.union`
            c2)
w_ul (n, m, ty_env, c_env, LCase e1 x1 x2 e2 e3) = do
    --First determine the type of the expression we case on
    (n1, m1, ty_env1, e1ty, subst1, c1) <- w_ul (n, m, ty_env, c_env, e1)
        
    let (n2, a1) = freshTyVar n1
        (n3, a2) = freshTyVar n2
        (m2, b1) = freshAnnVar m1
        (m3, b2) = freshAnnVar m2
        
    --We confirm that e1ty is indeed a list
    --Furthermore the substitution over a1 now tells us the type
    --of the elements
    --Next we can insert the bindings into the type environment
    (m4, subst2, c2) <- u_cfa (m3, e1ty, TList (S.singleton b1) (TVar a1))
    let ty_env2 = M.insert x1 (Type (substTyVar subst2 a1)) ty_env
        (TList annS ty) = e1ty
        lty = e1ty
        s2s1Env = \env -> substEnv subst2 (substEnv subst1 env)
        ty_env3 = M.insert x2 (Type lty) (s2s1Env ty_env2)
    --We can pass this updated environment to e2 to determine its type
    (n4, m5, ty_env4, e2ty, subst3, c3) <- w_ul (n3, m4, ty_env3, c_env, e2)
    --We may not pass it to e3. Both components should not be allowed to use in e3
    (n5, m6, ty_env5, e3ty, subst4, c4) <- w_ul (n4, m5, ty_env, c_env, e3)
    --Types of e2 and e3 should be equal
    (m7, subst5, c5) <- u_cfa_Br (m6, substTy subst4 e2ty, e3ty)
    --We can remove the bindings for the result of the program
    let ty_env6 = M.delete x1 $ M.delete x2 $ ty_env5 `M.union` ty_env4 `M.union` ty_env1
    return $
        (n5, m7, ty_env6, substTyAnn subst5 (substTy subst5 e3ty), subst5 `pointSubst` subst4 `pointSubst` subst3 `pointSubst` subst1,
        c5
        `S.union`
        substConstr subst5 c4
        `S.union`
        substConstr subst5 (
            substConstr subst4 c3)
        `S.union`
        substConstr subst5 (
            substConstr subst4 (
                substConstr subst3 c1))
        )


--Determine next free variables
freshTyVar :: Integer -> (Integer, TyVar)
freshTyVar n = 
    let var = "a" ++ show n
    in (n + 1, var)

freshAnnVar :: Integer -> (Integer, AnnVar)
freshAnnVar n = 
    let var = "b" ++ show n
    in (n + 1, var) 


--Defines all the freevariables in a ty/tyscheme/tyenv
freeVarsTy :: Ty -> S.Set TyVar
freeVarsTy (TVar v) = S.singleton v
freeVarsTy (Func ann t1 t2) = freeVarsTy t1 `S.union` freeVarsTy t2
freeVarsTy (TList annS t) = freeVarsTy t
freeVarsTy (TPair ann t1 t2) = freeVarsTy t1 `S.union` freeVarsTy t2
freeVarsTy _ = S.empty

freeVarsTyS :: TyScheme -> S.Set TyVar
freeVarsTyS (ForAll vars t) = (freeVarsTy t) `S.difference` S.fromList vars
freeVarsTyS (Type t) = freeVarsTy t

freeVarsEnv :: TyEnv -> S.Set TyVar
freeVarsEnv env = M.foldr (\x y -> freeVarsTyS x `S.union` y) S.empty env


--Set of substitution functions over different
--datatypes
substAnnVar :: Subst -> AnnVar -> AnnVar
substAnnVar (Subst _ annSub) var =
    case M.lookup var annSub of
        Just ann -> ann
        Nothing -> var

substAnnU :: Subst -> AnnU -> AnnU
substAnnU subst (AVar var) = AVar $ substAnnVar subst var
substAnnU _ annU = annU

substAnn :: Subst -> Ann -> Ann
substAnn subst annSet = S.map (substAnnU subst) annSet

substConstrU :: Subst -> ConstrU -> ConstrU
substConstrU subst (Sup var ann) = Sup (substAnnVar subst var) (substAnn subst ann)

substConstr :: Subst -> Constr -> Constr
substConstr subst constrSet = S.map (substConstrU subst) constrSet

substTyVar :: Subst -> TyVar -> Ty
substTyVar (Subst tySub _) var = 
    case M.lookup var tySub of
        Just t -> t
        Nothing -> TVar var

substTyAnn :: Subst -> Ty -> Ty
substTyAnn subst (Func ann t1 t2) = Func (substAnnVar subst ann) (substTyAnn subst t1) (substTyAnn subst t2)
substTyAnn subst (TPair ann t1 t2) = TPair (substAnnVar subst ann) (substTyAnn subst t1) (substTyAnn subst t2)
substTyAnn subst (TList annS t) = TList (S.map (substAnnVar subst) annS) t
substTyAnn subs t = t

substTy :: Subst -> Ty -> Ty
substTy subst (TVar var) = substTyVar subst var
substTy subst (Func ann t1 t2) = Func ann (substTy subst t1) (substTy subst t2)
substTy subst (TPair ann t1 t2) = TPair ann (substTy subst t1) (substTy subst t2)
substTy subst (TList annS t) = TList annS (substTy subst t)
substTy subst t = subst `seq` t

substTyS :: Subst -> TyScheme -> TyScheme
substTyS subst (Type t) = Type $ substTy subst t
substTyS (Subst tySub annSub)(ForAll vars t) = 
    let tySub' = M.filterWithKey (\k _ -> not $ elem k vars) tySub
    in ForAll vars (substTy (Subst tySub' annSub) t)

substTySAnn :: Subst -> TyScheme -> TyScheme
substTySAnn subst (Type t) = Type $ substTy subst t
substTySAnn (Subst tySub annSub)(ForAll vars t) = 
    let tySub' = M.filterWithKey (\k _ -> not $ elem k vars) tySub
    in ForAll vars (substTyAnn (Subst tySub' annSub) t)

substEnv :: Subst -> TyEnv -> TyEnv
substEnv subst env = M.map (substTySAnn subst . substTyS subst) env

--Sequence substitution
pointSubst :: Subst -> Subst -> Subst
pointSubst subst1 subst2 = 
    subMap (substTy subst1) (substAnnVar subst1) subst2 `subUnion` subst1

--Helper functions for union and mapping of type variables to tys
--and annotation variables to annotation variables
subUnion :: Subst -> Subst -> Subst
subUnion (Subst tySub1 annSub1) (Subst tySub2 annSub2) = 
    Subst (tySub1 `M.union` tySub2) (annSub1 `M.union` annSub2)

subMap :: (Ty -> Ty) -> (AnnVar -> AnnVar) -> Subst -> Subst
subMap fty fann (Subst tySub annSub) = 
    Subst (M.map fty tySub) (M.map fann annSub)

--Substitution of type variables for use in generalization
substituteWith :: TyVar -> TyVar -> Ty -> Ty
substituteWith var freshvar (Func ann t1 t2) = Func ann (substituteWith var freshvar t1) (substituteWith var freshvar t2)
substituteWith var freshvar (TPair ann t1 t2) = TPair ann (substituteWith var freshvar t1) (substituteWith var freshvar t2)
substituteWith var freshvar (TList annS t) = TList annS (substituteWith var freshvar t)
substituteWith var freshvar (TVar var') = if var == var'
                                            then TVar freshvar
                                            else TVar var
substituteWith var freshvar t = t


--Preprocessing that assigns a unique program point to each Expression
--that should contain one.
assignProgramPoints :: (Integer, Expr) -> (Integer, Expr)
assignProgramPoints (n, Fn _ x e) =
    let (n', e') = assignProgramPoints (n + 1, e)
    in (n', Fn n x e')
assignProgramPoints (n, Fun _ f x e) =
    let (n', e') = assignProgramPoints (n + 1, e)
    in (n', Fun n f x e')
assignProgramPoints (n, App e1 e2) =
    let (n', e1') = assignProgramPoints (n, e1)
        (n'', e2') = assignProgramPoints (n', e2)
    in (n'', App e1' e2')
assignProgramPoints (n, Let x e1 e2) =
    let (n', e1') = assignProgramPoints (n, e1)
        (n'', e2') = assignProgramPoints (n', e2)
    in (n'', Let x e1' e2')
assignProgramPoints (n, ITE e1 e2 e3) =
    let (n', e1') = assignProgramPoints (n, e1)
        (n'', e2') = assignProgramPoints (n', e2)
        (n''', e3') = assignProgramPoints (n'', e3)
    in (n''', ITE e1' e2' e3')
assignProgramPoints (n, Oper op e1 e2) = 
    let (n', e1') = assignProgramPoints (n, e1)
        (n'', e2') = assignProgramPoints (n', e2)
    in (n'', Oper op e1' e2')
assignProgramPoints (n, Pair _ e1 e2) =
    let (n', e1') = assignProgramPoints (n + 1, e1)
        (n'', e2') = assignProgramPoints (n', e2)
    in (n'', Pair n e1' e2')
assignProgramPoints (n, PCase e1 x1 x2 e2) =
    let (n', e1') = assignProgramPoints (n, e1)
        (n'', e2') = assignProgramPoints (n', e2)
    in (n'', PCase e1' x1 x2 e2')
assignProgramPoints (n, Nil p) = (n + 1, Nil n)
assignProgramPoints (n, Cons p e l) =
    let (n', e') = assignProgramPoints (n + 1, e)
        (n'', l') = assignProgramPoints (n', l)
    in (n'', (Cons n e' l'))
assignProgramPoints (n, LCase e1 x1 x2 e2 e3) =
    let (n', e1') = assignProgramPoints (n, e1)
        (n'', e2') = assignProgramPoints (n', e2)
        (n''', e3') = assignProgramPoints (n'', e3)
    in (n''', LCase e1' x1 x2 e2' e3')
assignProgramPoints ne = ne