module View where

import Data.Set as S
import Data.List as L

import Definitions

class View a where
    view :: a -> S.Set Integer -> a

instance View Ty where
    view (Func _ t1 t2) ppoints = 
        Func (show $ S.toList ppoints) t1 t2
    view (TPair _ t1 t2) ppoints =
        TPair (show $ S.toList ppoints) t1 t2
    view (TList _ t) ppoints = 
        TList (S.map show ppoints) t