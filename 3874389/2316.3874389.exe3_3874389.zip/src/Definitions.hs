module Definitions where

import Data.Map as M
import Data.Set as S

type AnnVar = String
type TyVar = String
type TyEnv = M.Map String TyScheme
type ConstrEnv = M.Map String Constr

data AnnU = AVar AnnVar | Single Integer
    deriving (Ord, Eq, Show)
type Ann = S.Set AnnU

data ConstrU = Sup AnnVar Ann
    deriving (Ord, Eq, Show)
type Constr = S.Set ConstrU

data Ty = TVar TyVar | Nat | Boolean | TPair AnnVar Ty Ty | 
          Func AnnVar Ty Ty | TList (S.Set AnnVar) Ty
    deriving (Eq, Show)
data TyScheme = Type Ty | ForAll [TyVar] Ty
    deriving (Eq, Show)
data Subst = Subst (M.Map TyVar Ty) (M.Map AnnVar AnnVar)
    deriving (Eq, Show)