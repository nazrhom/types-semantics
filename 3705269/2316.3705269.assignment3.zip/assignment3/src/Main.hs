-- (C) 2013-14 Pepijn Kokke & Wout Elsinghorst
-- Modifications made Jurriaan Hage

{-# LANGUAGE DoAndIfThenElse #-}

module Main where

import qualified Data.Map as Map

import Ast
import Parsing
import Data.Set (Set)
import Data.Map (Map)
import Data.List
import System.Environment

run :: String -> IO ()   
run name = do
    exps <- parse name
    let (ty,tysubst,constr) = w Map.empty exps 0

    putStrLn $ "Execute Wcfa for " ++ name
    putStrLn $ "Type: " ++ show ty
    putStrLn $ "Type constraints: " ++ show constr

-- |Parse and label program
parse :: String -> IO Expr
parse programName = do
  let fileName = programName++".fun"
  content <- readFile fileName
  return (parseExpr content)

main = do
    args <- getArgs

    if length args > 1 then do
        let p = head args
        run p
    else
        error "No arguments given"

-- Get a fresh typevar
fresh :: Integer -> Ty
fresh i = let name = "x" ++ show (i+1) in TyVar name

-- Get a fresh annotation variable
freshann :: Integer -> AnnVar
freshann i = i+1

instantiate :: TyScheme -> Ty
instantiate (Ty t) = t

-- Algorithm U takes an environment, in order to check if a is free for some cases
u :: TyEnv -> Ty -> Ty -> TySubst
u env TyNat TyNat = id
u env TyBool TyBool = id
u env (TyFunc τ₁ τ₂ π₁) (TyFunc τ₃ τ₄ π₂) =
    let θ₁ = u env τ₁ τ₃
        θ₂ = u env (θ₁ τ₂) (θ₁ τ₄)
    in θ₂ . θ₁
u env a@(TyVar _) τ | chk env a τ = (\x ->  τ)
                    | otherwise = error "Cannot unify"
u env τ a@(TyVar _) | chk env a τ = (\x -> τ)
                    | otherwise = error "Cannot unify"
u _ _ _ = error "Cannot unify"

-- Check if the second argument is not free, and if both types are equal
chk :: TyEnv -> Ty -> Ty -> Bool
chk env tv@(TyVar v) ty = tv == ty || not isfree where
    isfree = case Map.lookup v env of
                Just _  -> False
                Nothing -> True

w :: TyEnv -> Expr -> Integer -> (Ty, TySubst, Constr)
w env (Integer i) n   = (TyNat, id, CEmpty)
w env (Bool b) n  = (TyBool, id, CEmpty)
w env (Var v) n  = (instantiate (lookup' v env), id, CEmpty)
w env (Fn pi x t1) n  = let α₁ = fresh n
                            env' = Map.insert x (Ty α₁) env
                            (τ₂,θ,c) = w env' t1 (n+2)
                            β = freshann (n+1)
                      in (TyFunc (θ α₁) τ₂ β, θ, CUnion c (CSuper β (APi pi)))

w env (Fun pi f x t1) n = let α₁ = fresh n
                              α₂ = fresh (n+1)
                              β = freshann (n+2)
                              env' = Map.insert x (Ty α₁) env
                              env'' = Map.insert f (Ty $ TyFunc α₁ α₂ β) env'
                              (τ₂, θ₁, c) = w env'' t1 (n+3)
                              θ₂ = u env'' τ₂ (θ₁ α₂)
                          in (TyFunc (θ₂ (θ₁ α₁))
                                     (θ₂ τ₂)
                                     undefined -- (θ₂ (θ₁ (TyVar (show β)))) -- Does not work
                             , θ₂.θ₁, CUnion (subst' θ₂ c) (CSuper
                                 β -- (θ₂ (θ₁ (TyVar $ show β))) -- Does not work
                                 (APi pi))
                             )

w env (App t1 t2) n = let (τ₁, θ₁, c₁) = w env t1 n
                          (τ₂, θ₂, c₂) = w (subst θ₁ env) t2 n
                          α = fresh (n+1)
                          β = freshann (n+2)
                          θ₃ = u env (θ₂ τ₁) (TyFunc τ₂ α β)
                      in (θ₃ α, θ₃.θ₂.θ₁, CUnion (subst' θ₃ (subst' θ₂ c₁)) (subst' θ₃ c₂))

w env (Let x e1 e2) n = let (τ₁, θ₁, c₁) = w env e1 n
                            env' = Map.insert x (Ty τ₁) env
                            (τ₂, θ₂, c₂) = w (subst θ₁ env') e2 n
                        in (τ₂, θ₂.θ₁, CUnion (subst' θ₂ c₁) c₂)

w env (ITE c t e) n = let (τ₀, θ₀, c₀) = w env c n
                          (τ₁, θ₁, c₁) = w (subst θ₀ env) t n
                          (τ₂, θ₂, c₂) = w (subst θ₁ (subst θ₀ env)) e n
                          θ₃ = u env (θ₂ (θ₁ τ₀)) TyBool
                          θ₄ = u env (θ₃ τ₂) (θ₃ (θ₂ τ₁))
                      in (θ₄ (θ₃ τ₂), θ₄.θ₃.θ₂.θ₁.θ₀, CUnion
                          (subst' θ₄ (subst' θ₃ (subst' θ₂ (subst' θ₁ c₀))))
                          (subst' θ₄ (subst' θ₃ c₂))
                         )

w env (Oper op e1 e2) n = let (τ₁, θ₁, c₁) = w env e1 n
                              (τ₂, θ₂, c₂) = w (subst θ₁ env) e2 n
                              θ₃ = u env (θ₂ τ₁) τ₁
                              θ₄ = u env (θ₃ τ₂) τ₂
                          in (TyFunc τ₁ τ₂ 0, θ₄.θ₃.θ₂.θ₁, CUnion
                              (subst' θ₄ (subst' θ₃ (subst' θ₂ c₁)))
                              (subst' θ₄ (subst' θ₃ c₂))
                             )

-- Do a lookup that fails whan nothings is found
lookup' :: Name -> TyEnv -> TyScheme
lookup' a env = case Map.lookup a env of
    Nothing -> error $ "Could not find " ++ show a ++ " in env"
    Just x -> x

-- Execute type subst on environment
subst :: TySubst -> TyEnv -> TyEnv
subst s env = Map.fromList $ map f (Map.toList env) where
    f (n, (Ty v)) = (n, Ty $ s v)
    f x = x

-- Execute type subst on constraint
subst' :: TySubst -> Constr -> Constr
subst' s CEmpty = CEmpty
subst' s (CSuper annvar ann) = undefined
