module Ast where

import Prelude hiding (foldMap, pi)

data Op 
  = Add | Sub | Mul | Div  
  deriving (Eq,Show)
  
type Pi    = Int     -- For numbering lambda's etc. that can then be tracked in the analysis
type Name  = String  -- For identifier names

data Expr
  = Integer    Integer
  | Bool       Bool
  | Var        Name
  | Fun        Pi   Name Name Expr
  | Fn         Pi   Name Expr
  | App        Expr Expr
  | Let        Name Expr Expr
  | IfThenElse Expr Expr Expr
  | Oper       Op   Expr Expr
  | Pair       Pi   Expr Expr
  | PCase      Expr Name Name Expr
  | Nil        Pi
  | Cons       Pi   Expr Expr
  | LCase      Expr Name Name Expr Expr
  deriving (Eq, Show)

bin :: Name -> Expr -> Expr -> Expr
bin op x y = Oper r x y where
  r = case op of
        "+" -> Add
        "-" -> Sub
        "*" -> Mul
        "/" -> Div
        _   -> undefined

-- Applies the mapping function (snd . f) to the expression in a depth-first
-- manner, and along the way keeps track of an accumulator.
foldMap :: (a -> Expr -> (a, Expr)) -> a -> Expr -> (a, Expr)
foldMap f i (Fun pi self var expr)       = let (j, expr')  = foldMap f i expr
                                           in f j (Fun pi self var expr')
foldMap f i (Fn pi var expr)             = let (j, expr')  = foldMap f i expr
                                           in f j (Fn pi var expr')
foldMap f i (App g arg)                  = let (j, g')     = foldMap f i g
                                               (k, arg')   = foldMap f j arg
                                           in f k (App g' arg')
foldMap f i (Let var expr body)          = let (j, expr')  = foldMap f i expr
                                               (k, body')  = foldMap f j body
                                           in f k (Let var expr' body')
foldMap f i (IfThenElse cond true false) = let (j, cond')  = foldMap f i cond
                                               (k, true')  = foldMap f j true
                                               (l, false') = foldMap f k false
                                           in f l (IfThenElse cond' true' false')
foldMap f i (Oper op lhs rhs)            = let (j, lhs')   = foldMap f i lhs
                                               (k, rhs')   = foldMap f j rhs
                                           in f k (Oper op lhs' rhs')
foldMap f i (Pair pi el er)              = let (j, el')    = foldMap f i el
                                               (k, er')    = foldMap f j er
                                           in f k (Pair pi el' er')
foldMap f i (PCase expr nl nr body)      = let (j, expr')  = foldMap f i expr
                                               (k, body')  = foldMap f j body
                                           in f k (PCase expr' nl nr body')
foldMap f i (Cons pi h t)                = let (j, h')     = foldMap f i h
                                               (k, t')     = foldMap f j t
                                           in f k (Cons pi h' t')
foldMap f i (LCase expr nh nt body nil)  = let (j, expr')  = foldMap f i expr
                                               (k, body')  = foldMap f j body
                                               (l, nil')   = foldMap f k nil
                                           in f l (LCase expr' nh nt body' nil')
foldMap f i literal                      = f i literal

-- Assigns a unique integer to every program point in the expression.
makePisUnique :: Expr -> Expr
makePisUnique = snd . (foldMap aux 0)
  where aux i (Fun _ self var expr) = (i + 1, Fun i self var expr)
        aux i (Fn _ var expr)       = (i + 1, Fn i var expr)
        aux i (Pair _ el er)        = (i + 1, Pair i el er)
        aux i (Nil _)               = (i + 1, Nil i)
        aux i (Cons _ h t)          = (i + 1, Cons i h t)
        aux i expr                  = (i, expr)
