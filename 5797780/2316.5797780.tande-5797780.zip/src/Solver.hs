module Solver (
  Constraint (..),
  solve
) where

import qualified Data.IntSet as S
import qualified Data.Map as M

import Ast (Pi)
import Prelude hiding (pi)
import TypeSystem (AnnotationVariable)

data Constraint
  = Element Pi AnnotationVariable
  | Subset AnnotationVariable AnnotationVariable
  deriving (Show)

type PiMap = M.Map AnnotationVariable S.IntSet
type Edge = (AnnotationVariable, AnnotationVariable)

isEdge :: Constraint -> Bool
isEdge (Element _ _) = False
isEdge (Subset _ _)  = True

isSeed :: Constraint -> Bool
isSeed (Element _ _) = True
isSeed (Subset _ _)  = False

getEdges :: [Constraint] -> [Edge]
getEdges = map extract . filter isEdge
  where extract (Subset x y)  = (x, y)
        extract (Element _ _) = undefined

-- Returns the direct supersets of the given set (not including the set itself).
supersets :: [Edge] -> AnnotationVariable -> [AnnotationVariable]
supersets edges subset = fmap snd $ filter ((== subset) . fst) edges

-- Returns all supersets of the given set (including itself).
transitiveSupersets :: [Edge] -> AnnotationVariable -> [AnnotationVariable]
transitiveSupersets edges subset = S.toList $ aux S.empty $ [subset]
  where aux current []  = current
        aux current new =
          let extra       = S.fromList $ concatMap (supersets edges) new
              nextCurrent = S.union current $ S.fromList new
          in  aux nextCurrent  $ S.toList $ S.difference extra nextCurrent

getSeeds :: [Constraint] -> [(AnnotationVariable, Pi)]
getSeeds = map extract . filter isSeed
  where extract (Element pi ann) = (ann, pi)
        extract (Subset _ _)     = undefined

-- For every annotation variable in the list, adds the pi to its set.
addPi :: [AnnotationVariable] -> Pi -> PiMap -> PiMap
addPi into pi current = foldl addPiForKey current into
  where addPiForKey anns i = M.insertWith S.union i (S.singleton pi) anns

-- Adds pi to the set and all transitive supersets for the annotation variable.
distributePi :: [Edge] -> (AnnotationVariable, Pi) -> PiMap -> PiMap
distributePi edges (var, pi) = addPi (transitiveSupersets edges var) pi

solve :: [Constraint] -> (AnnotationVariable -> [Pi])
solve constraints =
  let seeds      = getSeeds constraints
      edges      = getEdges constraints
      distribute = flip $ distributePi edges
      solution   = foldl distribute M.empty seeds
      getPiSet x = S.toList $ M.findWithDefault S.empty x solution
  in  getPiSet
