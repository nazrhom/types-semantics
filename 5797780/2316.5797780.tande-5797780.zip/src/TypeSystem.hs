module TypeSystem (
  AnnotationVariable,
  GenericType (..),
  GenericTypeScheme (..),
  SolvedType,
  Type,
  TypeScheme,
  TypeVariable,
  mapAnnotations,
  mapTypeScheme,
  quantifyFreeVariables,
  reduceFreeVariables,
  substituteVariable
) where

import qualified Data.IntSet as S

import Ast (Pi)
import Data.Char (chr, ord)
import Prelude hiding (foldMap)

-- Type and annotation variables are identified by a number.
type TypeVariable = Int
type AnnotationVariable = Int

-- Inference is divided into two stages: type inference where all annotation
-- variables are symbolic, and solving, after which all annotation variables are
-- replaced with an actual set of program points. To support this, types are
-- parametrized over the annotation type.

data GenericType ann
  = Symbolic TypeVariable
  | Bool
  | Int
  | Function ann (GenericType ann) (GenericType ann)
  | Pair ann (GenericType ann) (GenericType ann)
  | List ann (GenericType ann)
  deriving (Eq)

data GenericTypeScheme ann
  = Concrete (GenericType ann)
  | ForAll TypeVariable (GenericTypeScheme ann)
  deriving (Eq)

type Type = GenericType AnnotationVariable
type TypeScheme = GenericTypeScheme AnnotationVariable
type SolvedType = GenericType [Pi]

-- Functions for pretty printing type signatures. This is split into two: one
-- for showing annotations, which go on a line by themselves, above the type
-- signatures, and one for the type signatures themselves.

fill :: Char -> String -> String
fill filler str = take (length str) $ repeat filler

-- Like Haskell, print type variables as lowercase letters. (I don't handle the
-- case of more than 26 type variables; Fun is a useless language anyway, so if
-- you are writing a program that has more than 26 free variables, you would
-- be better off spending your time to acutally do something useful.)
showTypeVariable :: TypeVariable -> String
showTypeVariable x = [chr $ ((x `mod` 26) + ord 'a')]

showType :: Show a => GenericType a -> String
showType (Symbolic x)         = showTypeVariable x
showType Bool                 = "Bool"
showType Int                  = "Int"
showType (Function ann dn cn) = (showNestedType dn) ++ " -" ++ (fill '-' $ show ann) ++ "-> " ++ (showNestedType cn)
showType (Pair ann tl tr)     = "(" ++ (showType tl) ++ ", " ++ (showType tr) ++ ")" ++ (fill ' ' $ show ann)
showType (List ann ct)        = "List" ++ (fill ' ' $ show ann) ++ " " ++ (showNestedType ct)

showNestedType :: Show a => GenericType a -> String
showNestedType (Function ann dn cn) = "(" ++ (showType $ Function ann dn cn) ++ ")"
showNestedType (List ann ct)        = "(" ++ (showType $ List ann ct) ++ ")"
showNestedType otherType            = showType otherType

showAnnotation :: Show a => GenericType a -> String
showAnnotation (Function ann dn cn) = (showNestedAnnotation dn) ++ "  " ++ (show ann) ++ "   " ++ (showNestedAnnotation cn)
showAnnotation (Pair ann tl tr)     = " " ++ (showAnnotation tl) ++ "  " ++ (showAnnotation tr) ++ " " ++ (show ann)
showAnnotation (List ann ct)        = "    " ++ (show ann) ++ " " ++ (showNestedAnnotation ct)
showAnnotation ct                   = fill ' ' $ showType ct

showNestedAnnotation :: Show a => GenericType a -> String
showNestedAnnotation (Function ann dn cn) = " " ++ (showAnnotation $ Function ann dn cn) ++ " "
showNestedAnnotation (List ann ct)        = " " ++ (showAnnotation $ List ann ct) ++ " "
showNestedAnnotation ct                   = showAnnotation ct

showScheme1 :: Show a => GenericTypeScheme a -> String
showScheme1 (Concrete ct) = showAnnotation ct
showScheme1 (ForAll _ qt) = "           " ++ (showScheme1 qt)

showScheme2 :: Show a => GenericTypeScheme a -> String
showScheme2 (Concrete ct) = showType ct
showScheme2 (ForAll x qt) = "For all " ++ (showTypeVariable x) ++ ": " ++ (showScheme2 qt)

collapseLines :: [String] -> String
collapseLines str =
  let (top : bot : []) = str
      pick (a, b)      = if a == ' ' then b else a
  in  map pick $ zip top bot

instance Show a => Show (GenericTypeScheme a) where
  show scheme = (showScheme1 scheme) ++ "\n" ++ (showScheme2 scheme)

-- The show instance for types is collapsed to one line by default, as opposed
-- to the show instance for type schemes, which uses two lines and adds
-- annotations as superscripts.
instance Show a => Show (GenericType a) where
  show ct = collapseLines [showAnnotation ct, showType ct]

-- Utility methods for dealing with types.

foldMap :: (z -> GenericType a -> (z, GenericType a)) -> z -> GenericType a -> (z, GenericType a)
foldMap f i (Function ann dn cn) = let (j, dn') = foldMap f i dn
                                       (k, cn') = foldMap f j cn
                                   in  f k $ Function ann dn' cn'
foldMap f i (Pair ann tl tr)     = let (j, tl') = foldMap f i tl
                                       (k, tr') = foldMap f j tr
                                   in  f k $ Pair ann tl' tr'
foldMap f i (List ann ct)        = let (j, ct') = foldMap f i ct
                                   in  f j $ List ann ct'
foldMap f i primitive            = f i primitive

-- Map is foldMap but ignoring the fold part.
mapType :: (GenericType a -> GenericType a) -> GenericType a -> GenericType a
mapType f = snd . foldMap (\i ct -> (i, f ct)) (0 :: Int)

-- Prepends a ForAll quantifier for every type variable in the list.
wrapQuantifiers :: [TypeVariable] -> GenericType a -> GenericTypeScheme a
wrapQuantifiers qs ct = foldl (flip ForAll) (Concrete ct) qs

getFreeVariables :: GenericType a -> S.IntSet
getFreeVariables = fst . foldMap aux S.empty
  where aux acc (Symbolic x) = (S.insert x acc, Symbolic x)
        aux acc otherType    = (acc, otherType)

-- Appends a ForAll quantifier for every free type variable in the type.
quantifyFreeVariables :: GenericType a -> GenericTypeScheme a
quantifyFreeVariables ct = wrapQuantifiers (S.toList $ getFreeVariables ct) ct

-- Given a seed and a set of integers, constructs a function that has the set as
-- domain and 0, 1, ..., n - 1 as codomain (where n is the number of elements in
-- the set).
minimizer :: Int -> S.IntSet -> (Int -> Int)
minimizer _    ann | S.null ann = id
minimizer seed ann | otherwise  =
  let (m, rest)  = S.deleteFindMin ann
      fallback   = minimizer (seed + 1) rest
      minimize i = if i == m then seed else fallback i
  in  minimize

-- Given a type, ensures that the free variables are numbered minimally. That
-- is, 0, 1, ..., n - 1 for n free variables.
reduceFreeVariables :: GenericType a -> GenericType a
reduceFreeVariables ct =
  let update = minimizer 0 $ getFreeVariables ct
      reduce (Symbolic x) = Symbolic $ update x
      reduce otherType    = otherType
  in  mapType reduce ct

mapAnnotations :: (a -> b) -> GenericType a -> GenericType b
mapAnnotations f (Function annotation domain codomain) =
  let annotation' = f annotation
      domain'     = mapAnnotations f domain
      codomain'   = mapAnnotations f codomain
  in  Function annotation' domain' codomain'
mapAnnotations f (Pair annotation tl tr) =
  let annotation' = f annotation
      tl'         = mapAnnotations f tl
      tr'         = mapAnnotations f tr
  in  Pair annotation' tl' tr'
mapAnnotations f (List annotation ct) =
  let annotation' = f annotation
      ct'         = mapAnnotations f ct
  in  List annotation' ct'
mapAnnotations _ (Symbolic x) = Symbolic x
mapAnnotations _ Bool         = Bool
mapAnnotations _ Int          = Int

substituteVariable :: TypeVariable -> GenericType a -> GenericType a -> GenericType a
substituteVariable x ct = mapType aux
  where aux (Symbolic y) | x == y = ct
        aux otherType             = otherType

mapTypeScheme :: (GenericType a -> GenericType b) -> GenericTypeScheme a -> GenericTypeScheme b
mapTypeScheme f (ForAll x qt) = ForAll x $ mapTypeScheme f qt
mapTypeScheme f (Concrete ct) = Concrete $ f ct
