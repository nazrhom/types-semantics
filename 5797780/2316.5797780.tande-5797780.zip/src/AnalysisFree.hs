module AnalysisFree (
  Analysis,
  annotateNull,
  annotatePi,
  annotateSubset,
  emptyContext,
  error,
  getFresh,
  lookup,
  popBinding,
  pushBinding,
  runAnalysis,
  solveConstraints,
  stash,
  substitute,
  unstash,
  with,
  withBinding
) where

import Ast (Name, Pi)
import Control.Monad.Free
import Data.List (find)
import Prelude hiding (error, lookup, pi)
import Solver (Constraint (Element, Subset), solve)
import TypeSystem (AnnotationVariable, TypeVariable)
import TypeSystem (GenericType (Symbolic))
import TypeSystem (SolvedType, Type, TypeScheme)
import TypeSystem (mapAnnotations, mapTypeScheme, substituteVariable)

-- Define a free monad for type inference. This is mainly a lot of boilerplate
-- with two goals:
--
--  * Abstract away failure. We will interpret Analysis a -> Either String a
--    for error handling, so inside the actual inference algorithm we can
--    pretend that failure never happens.
--
--  * Abstract away state. Every time we learn something through inference, we
--    need to update the environment to reflect the new information. This is
--    possible by making everything return a new environment in addition to its
--    result, and then threading and merging environments in the right way, but
--    this quickly becomes a mess. By using a monad, we can mostly ignore the
--    environment now, it is implicit everywhere and updated automatically.
--
--    Furthermore, we also want to apply knowledge gained by inference to types
--    that we had already, even if they were not in the environment. This is
--    achieved by "stashing" them before doing inference, and "unstashing" them
--    afterwards. I am not super happy with this, it feels a bit like a hack,
--    but it works. Perhaps a better way would be to work with type references
--    everywhere instead of types directly. (Basically that means this monad
--    would be a way to replicate references/pointers into a mutable heap in
--    Haskell ... I wonder whether this inference would be better implemented in
--    an imperative language with reference semantics.)
--
-- The operations defined in this module allow interacting with the analysis state.
--
-- Note that a free monad is really nothing more than a ton of boilerplate.
-- "Free" basically means "cheat by not reducing expressions". Perhaps a simpler
-- example is a free vector space. In the free vector space spanned by apple and
-- pear, you can add apples and pears. 1*apple + 1*pear = 1*apple + 1*pear!

data AnalysisFree a
  = AnnotateNull     (AnnotationVariable -> a)
  | AnnotatePi       Pi (AnnotationVariable -> a)
  | AnnotateSubset   AnnotationVariable AnnotationVariable a
  | Error            String a
  | GetFresh         (Type -> a)
  | Lookup           Name (TypeScheme -> a)
  | PopBinding       Name (TypeScheme -> a)
  | PushBinding      Name TypeScheme a
  | SolveConstraints Type (SolvedType -> a)
  | Stash            Type a
  | Substitute       TypeVariable Type a
  | Unstash          (Type -> a)

instance Functor AnalysisFree where
  fmap f (AnnotateNull h)              = AnnotateNull (f . h)
  fmap f (AnnotatePi pi h)             = AnnotatePi pi (f . h)
  fmap f (AnnotateSubset x y a)        = AnnotateSubset x y (f a)
  fmap f (Error err a)                 = Error err (f a)
  fmap f (GetFresh h)                  = GetFresh (f . h)
  fmap f (Lookup symbol h)             = Lookup symbol (f . h)
  fmap f (PopBinding symbol h)         = PopBinding symbol (f . h)
  fmap f (PushBinding symbol scheme a) = PushBinding symbol scheme (f a)
  fmap f (SolveConstraints ct h)       = SolveConstraints ct (f . h)
  fmap f (Stash ct a)                  = Stash ct (f a)
  fmap f (Substitute x ct a)           = Substitute x ct (f a)
  fmap f (Unstash h)                   = Unstash (f . h)

type Analysis = Free AnalysisFree

-- Creates an annotation variable that initially represents the empty set.
annotateNull :: Analysis AnnotationVariable
annotateNull = liftF $ AnnotateNull id

-- Creates an annotation variable with the constraint that pi is an element.
annotatePi :: Pi -> Analysis AnnotationVariable
annotatePi pi = liftF $ AnnotatePi pi id

-- Adds a constraint that x is a subset of y.
annotateSubset :: AnnotationVariable -> AnnotationVariable -> Analysis ()
annotateSubset x y = liftF $ AnnotateSubset x y ()

error :: String -> Analysis ()
error err = liftF $ Error err ()

getFresh :: Analysis Type
getFresh = liftF $ GetFresh id

lookup :: Name -> Analysis TypeScheme
lookup symbol = liftF $ Lookup symbol id

-- Removes the most recent binding from the environment and returns the type
-- scheme bound to the symbol. The provided symbol must be the most recently
-- bound one.
popBinding :: Name -> Analysis TypeScheme
popBinding symbol = liftF $ PopBinding symbol id

-- Adds a new binding to the environment.
pushBinding :: Name -> TypeScheme -> Analysis ()
pushBinding symbol scheme = liftF $ PushBinding symbol scheme ()

solveConstraints :: Type -> Analysis SolvedType
solveConstraints ct = liftF $ SolveConstraints ct id

-- Substitutes the type variable x with the given type in the environment.
substitute :: TypeVariable -> Type -> Analysis ()
substitute x ct = liftF $ Substitute x ct ()

-- Push a type onto the stash so that it will get updated during substitution.
stash :: Type -> Analysis ()
stash ct = liftF $ Stash ct ()

-- Pop a type off the stash.
unstash :: Analysis Type
unstash = liftF $ Unstash id

withBinding :: Name -> TypeScheme -> (Analysis a) -> Analysis a
withBinding symbol scheme inner = do
  pushBinding symbol scheme
  result <- inner
  _ <- popBinding symbol
  return result

-- Performs the inner analysis with the type stashed (so it might be modified by
-- the inner analysis), returns the type after the inner analysis.
with :: Type -> Analysis () -> Analysis Type
with ct inner = stash ct >> inner >> unstash

-- Define some data structures which are used for in the analysis interpreter.
-- This is used to keep track of the next fresh type variable and the current
-- environment, as well as constraints on annotation variables.

type Environment = [(Name, TypeScheme)]

data AnalysisContext = AnalysisContext {
  environment         :: Environment,
  constraints         :: [Constraint],
  stashes             :: [Type],
  nextFreshType       :: TypeVariable,
  nextFreshAnnotation :: AnnotationVariable
}

emptyContext :: AnalysisContext
emptyContext = AnalysisContext {
  environment         = [],
  constraints         = [],
  stashes             = [],
  nextFreshType       = 0,
  nextFreshAnnotation = 0
}

-- Define some utility functions for manipulating the context and error
-- handling.

lookupInEnvironment :: Environment -> Name -> Either String TypeScheme
lookupInEnvironment env symbol = case find ((== symbol) . fst) env of
  Just (_, scheme) -> Right scheme
  Nothing          -> Left $ "the symbol '" ++ symbol ++ "' is unbound"

mapSnd :: (b -> c) -> (a, b) -> (a, c)
mapSnd f (x, y) = (x, f y)

substituteInEnvironment :: TypeVariable -> Type -> Environment -> Environment
substituteInEnvironment x ct env = map (mapSnd $ mapTypeScheme $ substituteVariable x ct) env

substituteInStash :: TypeVariable -> Type -> [Type] -> [Type]
substituteInStash x ct = map $ substituteVariable x ct

pop :: Name -> Environment -> Either String (TypeScheme, Environment)
pop symbol [] = Left $ "PROGRAMMER ERROR: tried to pop '" ++ symbol ++ "' from an empty environment"
pop symbol ((symb, scheme) : newEnv) =
  if symbol /= symb
    then Left $ "PROGRAMMER ERROR: tried to pop '" ++ symbol ++ "' but '" ++ symb ++ "' must be popped first"
    else Right (scheme, newEnv)

-- We stuffed away error handling and state, but it has to be done *somewhere*.
-- This is that place. Essentially, it is an interpreter for analysis commands.

runAnalysis :: AnalysisContext -> Analysis a -> Either String a

runAnalysis _ (Pure a) = return a

runAnalysis context (Free (AnnotateNull h)) =
  let fresh      = nextFreshAnnotation context
      newContext = context { nextFreshAnnotation = fresh + 1 }
  in  return fresh >>= runAnalysis newContext . h

runAnalysis context (Free (AnnotatePi pi h)) =
  let fresh          = nextFreshAnnotation context
      newConstraints = (pi `Element` fresh) : (constraints context)
      newContext     = context {
        nextFreshAnnotation = fresh + 1,
        constraints         = newConstraints
      }
  in  return fresh >>= runAnalysis newContext . h

runAnalysis context (Free (AnnotateSubset x y a)) =
  let newConstraints = (x `Subset` y) : (constraints context)
      newContext     = context { constraints = newConstraints }
  in  return a >>= runAnalysis newContext

runAnalysis _ (Free (Error err _)) = Left err

runAnalysis context (Free (GetFresh h)) =
  let fresh      = nextFreshType context
      newContext = context { nextFreshType = fresh + 1 }
  in  return (Symbolic fresh) >>= runAnalysis newContext . h

runAnalysis context (Free (Lookup symbol h)) = do
  scheme <- lookupInEnvironment (environment context) symbol
  return scheme >>= runAnalysis context . h

runAnalysis context (Free (PopBinding symbol h)) = do
  (scheme, newEnvironment) <- pop symbol $ environment context
  let newContext = context { environment = newEnvironment }
  return scheme >>= runAnalysis newContext .h

runAnalysis context (Free (PushBinding symbol scheme a)) =
  let binding        = (symbol, scheme)
      newEnvironment = binding : (environment context)
      newContext     = context { environment = newEnvironment }
  in  return a >>= runAnalysis newContext

runAnalysis context (Free (SolveConstraints ct h)) =
  let getPiSet  = solve $ constraints context
      newScheme = mapAnnotations getPiSet ct
  in  return newScheme >>= runAnalysis context . h

runAnalysis context (Free (Substitute x ct a)) =
  let updateEnv   = substituteInEnvironment x ct
      updateStash = substituteInStash x ct
      newContext  = context {
        environment = updateEnv $ environment context,
        stashes     = updateStash $ stashes context
      }
  in  return a >>= runAnalysis newContext

runAnalysis context (Free (Stash ct a)) =
  let newContext = context { stashes = ct : (stashes context) }
  in  return a >>= runAnalysis newContext

runAnalysis context (Free (Unstash h)) =
  let (ct : types) = stashes context
      newContext = context { stashes = types }
  in  return ct >>= runAnalysis newContext . h
