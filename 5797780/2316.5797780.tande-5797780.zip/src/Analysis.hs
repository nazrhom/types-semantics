module Analysis (infer) where

import qualified Ast

import AnalysisFree
import Ast (Expr, Name, Pi)
import Prelude hiding (elem, error, head, lookup, pi, tail)
import TypeSystem

-- The actual type inference and analysis algorithm. State and error handling
-- have mostly been stuffed away into the Analysis monad, see also AnalysisFree.

inferFun :: Pi -> Name -> Name -> Expr -> Analysis Type
inferFun pi f arg body = do
  domainFresh   <- getFresh
  codomainFresh <- getFresh
  annotation    <- annotatePi pi
  pushBinding f   $ Concrete $ Function annotation domainFresh codomainFresh
  pushBinding arg $ Concrete domainFresh
  codomain <- infer body
  unify codomain codomainFresh
  domain   <- popBinding arg >>= instantiate
  unify domain domainFresh
  -- The type of f is also the type of the entire definition.
  -- Note that instantiate is a no-op because we pushed a concrete type.
  -- (That is also true for the domain above.)
  popBinding f >>= instantiate

inferFn :: Pi -> Name -> Expr -> Analysis Type
inferFn pi arg body = do
  domainFresh <- getFresh
  pushBinding arg $ Concrete domainFresh
  codomain    <- infer body
  -- By inferring the body we might have learned something about the domain.
  domain      <- popBinding arg >>= instantiate
  annotation  <- annotatePi pi
  return $ Function annotation domain codomain

instantiate :: TypeScheme -> Analysis Type
instantiate (Concrete ct) = return ct
instantiate (ForAll x qt) = do
  fresh <- getFresh
  ct    <- instantiate qt
  return $ substituteVariable x fresh ct

inferApp :: Expr -> Expr -> Analysis Type
inferApp f arg = do
  -- Infer the type of f, but stash it immediately. By inferring arg later on we
  -- might learn something about f. This is important when f is an endomorphism.
  infer f >>= stash
  argType    <- infer arg
  fType      <- unstash
  freshType  <- getFresh
  annotation <- annotateNull
  -- Unification will ensure that fType is a subtype of the function type on the
  -- right. In particular this means that argType can be a subtype of the domain
  -- of fType, so we don't poison argType. After unification, freshType will be
  -- the type of the codomain of f, which is what we need to return.
  with freshType $ unify fType $ Function annotation argType freshType

inferLet :: Name -> Expr -> Expr -> Analysis Type
inferLet symbol expr body = do
  exprType <- infer expr
  bodyType <- withBinding symbol (quantifyFreeVariables exprType) $ infer body
  return bodyType

-- Creates a fresh type and ensures that it is a supertype of both arguments.
inferSupertype :: Type -> Type -> Analysis Type
inferSupertype sub0 sub1 = do
  superType   <- getFresh
  superType'  <- with superType  $ unify sub0 superType
  superType'' <- with superType' $ unify sub1 superType'
  return superType''

inferIfThenElse :: Expr -> Expr -> Expr -> Analysis Type
inferIfThenElse cond true false = do
  condType  <- infer cond
  trueType  <- infer true
  falseType <- infer false
  -- The condition must be a boolean.
  unify condType Bool
  -- Make both branches a subtype of a fresh type and return the fresh type
  -- (which by then we hopefully have learned something about via unification).
  inferSupertype trueType falseType

inferOperator :: Expr -> Expr -> Analysis Type
inferOperator lhs rhs = do
  lhsType <- infer lhs
  rhsType <- infer rhs
  unify lhsType Int -- Operators only take integers.
  unify rhsType Int
  return Int        -- And the result is also an integer.

inferPair :: Pi -> Expr -> Expr -> Analysis Type
inferPair pi el er = do
  lType      <- infer el
  rType      <- infer er
  annotation <- annotatePi pi
  return $ Pair annotation lType rType

inferPCase :: Expr -> Name -> Name -> Expr -> Analysis Type
inferPCase pair nl nr body = do
  pairType   <- infer pair
  lTypeFresh <- getFresh
  rTypeFresh <- getFresh
  annotation <- annotateNull
  stash lTypeFresh
  stash rTypeFresh
  -- Note the order for unify here: we want our fresh pair type to be a
  -- supertype of the expression pair type, because it is like a function
  -- argument (a pcase expression is like a function: you could also opt
  -- for fst and snd functions and remove the syntax).
  unify pairType (Pair annotation lTypeFresh rTypeFresh)
  rType <- unstash
  lType <- unstash
  withBinding nl (Concrete lType) $ withBinding nr (Concrete rType) $ infer body

inferNil :: Pi -> Analysis Type
inferNil pi = do
  annotation <- annotatePi pi
  elemType   <- getFresh
  return $ List annotation elemType

inferCons :: Pi -> Expr -> Expr -> Analysis Type
inferCons pi head tail = do
  headType   <- infer head
  tailType   <- infer tail
  annotation <- annotatePi pi
  -- The type of the list is a supertype of the tail type and [head]. (If the
  -- tail is a list of apples and the head is a pear, we have a list of fruit.)
  -- This means that annotations get merged too; the annotations on the tail
  -- type are not discarded. This might seem like a bad idea because we know
  -- exactly where this list was constructed: at *this* cons. But if we discard
  -- the annotations on the tail, then after pattern matching on this list, we
  -- will have lost information about where the tail came from. So we don't
  -- throw away that information at the cost of imprecision.
  inferSupertype tailType $ List annotation headType

inferLCase :: Expr -> Name -> Name -> Expr -> Expr -> Analysis Type
inferLCase list nh nt body nil = do
  listType   <- infer list
  fresh      <- getFresh
  annotation <- annotateNull
  headType   <- with fresh $ unify listType (List annotation fresh)
  bodyType   <- withBinding nh (Concrete headType) $
                withBinding nt (Concrete listType) $ infer body
  nilType    <- infer nil
  -- Like an if-then-else, the return type of an lcase is a supertype of both of
  -- its branches.
  inferSupertype bodyType nilType

infer :: Expr -> Analysis Type
infer (Ast.Integer _)                  = return Int
infer (Ast.Bool _)                     = return Bool
infer (Ast.Var symbol)                 = lookup symbol >>= instantiate
infer (Ast.Fun pi f arg body)          = inferFun pi f arg body
infer (Ast.Fn pi arg body)             = inferFn pi arg body
infer (Ast.App f arg)                  = inferApp f arg
infer (Ast.Let symbol expr body)       = inferLet symbol expr body
infer (Ast.IfThenElse cond true false) = inferIfThenElse cond true false
infer (Ast.Oper _ lhs rhs)             = inferOperator lhs rhs
infer (Ast.Pair pi el er)              = inferPair pi el er
infer (Ast.PCase expr nl nr body)      = inferPCase expr nl nr body
infer (Ast.Nil pi)                     = inferNil pi
infer (Ast.Cons pi head tail)          = inferCons pi head tail
infer (Ast.LCase expr nh nt body nil)  = inferLCase expr nh nt body nil

-- The unification function, broken down into different cases with helper
-- functions. The unification algorithm takes variance into account when
-- possible. That is, unify a b does not mean that a and b become equal,
-- it means that a becomes a subtype of b. This can prevent some kinds of
-- poisioning in e.g. branches, where the type of the if-expression is a
-- supertype of both of its arms, so that the annotations on the arms don't have
-- to mix everywhere in the program. The substituteSuper* functions also help
-- here. (Try removing them and then see how that influences the
-- non_poisioned_*.fun sample programs.)

unify :: Type -> Type -> Analysis ()
unify (Function ax dx cx) (Function ay dy cy) = unifyFunctions ax ay dx dy cx cy
unify (Function ax dx cx) (Symbolic y)        = substituteSuperFunction y ax dx cx
unify (Pair ax lx rx) (Pair ay ly ry)         = unifyPairs ax ay lx ly rx ry
unify (Pair ax lx rx) (Symbolic y)            = substituteSuperPair y ax lx rx
unify (List ax ex) (List ay ey)               = unifyLists ax ay ex ey
unify (List ax ex) (Symbolic y)               = substituteSuperList y ax ex
unify (Symbolic x) ct  = substitute x ct
unify ct (Symbolic y)  = substitute y ct
unify cx cy | cx == cy = return ()
unify cx cy            = error $ "failed to unify '" ++ (show cx) ++ "' with '" ++ (show cy) ++ "'"

unifyFunctions :: AnnotationVariable -> AnnotationVariable -> Type -> Type -> Type -> Type -> Analysis ()
unifyFunctions annX annY domainX domainY codomainX codomainY = do
  -- [Idea: it would be nice before we make the recursive calls, to push some
  -- kind of message into the context that stores the current unification goal.
  -- That way, if unification fails in one of the recursive calls, it could
  -- include the original goal in the error message. Unfortunately I do not have
  -- the time to gold plate things like that here.]
  -- First of all, the domain and codomain must unify. Stash the codomains
  -- because we might learn something about them while unifying the domains.
  -- (For instance, if domainX == codomainX.)
  stash codomainX
  stash codomainY
  unify domainY domainX -- Note the reverse order: the domain is contravariant.
  codomainY' <- unstash
  codomainX' <- unstash
  unify codomainX' codomainY'
  -- The annotations must match as well, which is enforced by adding the
  -- appropriate constraints.
  annotateSubset annX annY

unifyPairs :: AnnotationVariable -> AnnotationVariable -> Type -> Type -> Type -> Type -> Analysis ()
unifyPairs annX annY lX lY rX rY = do
  stash rX
  stash rY
  unify lX lY
  rY' <- unstash
  rX' <- unstash
  unify rX' rY'
  annotateSubset annX annY

unifyLists :: AnnotationVariable -> AnnotationVariable -> Type -> Type -> Analysis ()
unifyLists annX annY elemX elemY = do
  unify elemX elemY
  annotateSubset annX annY

-- Substitutes the type variable with a fresh function type which is a supertype
-- of the given function type.
substituteSuperFunction :: TypeVariable -> AnnotationVariable -> Type -> Type -> Analysis ()
substituteSuperFunction x ann domain codomain = do
  -- Generate fresh types to build a fresh function type.
  domFresh   <- getFresh
  codomFresh <- getFresh
  annFresh   <- annotateNull
  -- Stash the domain and codomain because unification will modify them, and we
  -- want to use the modified versions later on. For the annotation this is not
  -- required, because annotations are symbolic. Constraints get added for the
  -- symbol, but the symbol itself does not change.
  stash domFresh
  stash codomFresh
  -- Make a supertype of the provided function type.
  unifyFunctions ann annFresh domain domFresh codomain codomFresh
  superCodomain <- unstash
  superDomain   <- unstash
  -- Substitute the variable with the function super type.
  substitute x $ Function annFresh superDomain superCodomain

substituteSuperPair :: TypeVariable -> AnnotationVariable -> Type -> Type -> Analysis ()
substituteSuperPair x ann tl tr = do
  tlFresh  <- getFresh
  trFresh  <- getFresh
  annFresh <- annotateNull
  stash tlFresh
  stash trFresh
  unifyPairs ann annFresh tl tlFresh tr trFresh
  superTr <- unstash
  superTl <- unstash
  substitute x $ Pair annFresh superTl superTr

substituteSuperList :: TypeVariable -> AnnotationVariable -> Type -> Analysis ()
substituteSuperList x ann elem = do
  elemFresh <- getFresh
  annFresh  <- annotateNull
  superElem <- with elemFresh $ unifyLists ann annFresh elem elemFresh
  substitute x $ List annFresh superElem
