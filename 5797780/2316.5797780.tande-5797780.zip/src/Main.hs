import Ast (Expr, makePisUnique)
import Analysis (infer)
import AnalysisFree (emptyContext, runAnalysis, solveConstraints)
import Parsing (parseExpr)
import System.Environment (getArgs)
import TypeSystem (quantifyFreeVariables, reduceFreeVariables)

main :: IO ()
main = do
  args <- getArgs
  case args of
    command : fname : [] -> handleCommand command fname
    _                    -> printUsage

handleCommand :: String -> String -> IO ()
handleCommand command fname = do
  source <- readFile fname
  let program = makePisUnique $ parseExpr source
  case command of
    "analyze" -> putStrLn $ "\n" ++ analyze program
    "print"   -> putStrLn $ "\n" ++ show program
    _         -> printUsage

analyze :: Expr -> String
analyze expr =
  let analysis = infer expr >>= solveConstraints
  in  case runAnalysis emptyContext analysis of
    Left err -> "Program is ill-typed: " ++ err ++ "."
    -- If type inference was successful, first ensure that the free variables
    -- are minimal (all those fresh variables in the inference algorithm can
    -- cause bloat, and we end up with seemingly random type names). Also
    -- prepend a ForAll to the free variables.
    Right tt -> show $ quantifyFreeVariables $ reduceFreeVariables tt

printUsage :: IO ()
printUsage = do
  putStrLn "Usage: funflow <command> <filename>"
  putStrLn ""
  putStrLn "Supported commands:"
  putStrLn "  analyze"
  putStrLn "  print"
