#!/bin/sh
parallel -j1 'echo && echo {} && dist/build/funflow/funflow analyze {}' ::: fun/*.fun
