{-# LANGUAGE DeriveDataTypeable        #-}

module Ast where

import Control.Lens
import Control.Lens.Plated
import Data.Data
import Data.Data.Lens (uniplate)

data Op
  = Add | Sub | Mul | Div | Eq
  deriving (Eq,Show,Data,Typeable)

type Pi    = String -- For numbering lambda's etc. that can then be tracked in the analysis
type Name  = String  -- For identifier names

data Expr
  = Integer Integer
  | Bool    Bool
  | Var     Name
  | Fun     Pi   Name Name Expr
  | Fn      Pi   Name Expr
  | App     Expr Expr
  | Let     Name Expr Expr
  | ITE     Expr Expr Expr
  | Oper    Op   Expr Expr
  | Pair    Pi   Expr Expr
  | PCase   Expr (Name, Name) Expr
  | Nil     Pi
  | Cons    Pi Expr Expr
  | LCase   Expr (Name, Name) Expr Expr
  deriving (Eq,Show,Data,Typeable)

instance Plated Expr where
  plate = uniplate

bin :: Name -> Expr -> Expr -> Expr
bin op x y = Oper r x y where
  r = case op of
        "+" -> Add
        "-" -> Sub
        "*" -> Mul
        "/" -> Div
        "==" -> Eq
