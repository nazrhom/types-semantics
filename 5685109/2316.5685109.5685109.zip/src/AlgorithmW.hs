{-# LANGUAGE TypeSynonymInstances, FlexibleInstances, DeriveDataTypeable #-}
module AlgorithmW
( Type (..)
, inferTy
, Constraints
, Constraint (..)
, Annotation (..)
)
where

import qualified Data.Map as M
import qualified Data.Set as S
import Control.Lens
import Control.Lens.Plated
import Data.Data
import Data.Data.Lens (uniplate)
import Control.Monad.Except
import Control.Monad.Reader
import Control.Monad.State
import Ast (Expr(..), Pi, Op(..))

import qualified Text.PrettyPrint as PP

type TyVar = String
type TyScVar = String

type TySub = M.Map TyVar Type
type AnnSub = M.Map AnnVar AnnVar

data SimpleSub = SimpleSub TySub AnnSub deriving (Show)

emptySubst :: SimpleSub
emptySubst = SimpleSub M.empty M.empty

infixr 5 <°>
(<°>) :: SimpleSub -> SimpleSub -> SimpleSub
(SimpleSub e1 e2) <°> (SimpleSub e3 e4) =
  SimpleSub (M.map (apply (simpleTySub e1)) e3 `M.union` e1) (M.mapWithKey (\k v -> case M.lookup v e2 of
    Nothing -> v
    Just b' -> b') e4 `M.union` e2)

simpleTySub :: TySub -> SimpleSub
simpleTySub s = SimpleSub s M.empty

simpleAnnSub :: AnnSub -> SimpleSub
simpleAnnSub s = SimpleSub M.empty s

type AnnVar = String
data Annotation = AVar AnnVar | Points (S.Set Pi) deriving (Eq, Ord, Show, Data, Typeable)

data Type = TVar TyVar
          | TNat
          | TBool
          | TFun Annotation Type Type
          | TPair Annotation Type Type
          | TList Annotation Type
  deriving (Eq, Ord, Data, Typeable)

instance Plated Type where
  plate = uniplate

data TypeScheme = TypeScheme [TyVar] Type
newtype TypeEnv = TypeEnv (M.Map TyScVar TypeScheme)

data Constraint = Constraint AnnVar Annotation deriving (Show)

type Constraints = [Constraint]

noConstraints :: Constraints
noConstraints = []

simplifyConstraints :: Constraints -> Constraints
simplifyConstraints cs = go cs []
  where
    go :: Constraints -> Constraints -> Constraints
    go ((Constraint var (AVar b)):cs) acc = go (cs ++ (apply (simpleAnnSub $ M.singleton b var) acc)) acc
    go (c:cs) acc = go cs (c:acc)
    go [] acc = acc

solveConstraints :: Constraints -> Type -> Type
solveConstraints cs (TFun (AVar b) e1 e2) = TFun (gatherMatching b cs) e1 e2
solveConstraints cs (TPair (AVar b) p1 p2) = TPair (gatherMatching b cs) p1 p2
solveConstraints cs (TList (AVar b) l1) = TList (gatherMatching b cs) l1
solveConstraints _ t = t

gatherMatching :: AnnVar -> Constraints -> Annotation
gatherMatching b cs = Points $ foldr gather S.empty cs
  where
  gather (Constraint var ann) acc | var == b = case ann of
    AVar _ -> acc
    Points ps -> ps `S.union` acc
                              | otherwise = acc
class Types a where
  ftv :: a -> S.Set String
  apply :: SimpleSub -> a -> a

instance {-# OVERLAPPABLE #-} Types a => Types [a] where
  ftv a = foldr S.union S.empty (map ftv a)
  apply s = map (apply s)

instance Types Type where
  ftv (TVar a) = S.singleton a
  ftv (TFun _ t1 t2) = ftv t1 `S.union` (ftv t2)
  ftv (TPair _ p1 p2) = ftv p1 `S.union` (ftv p2)
  ftv _ = S.empty

  apply (SimpleSub tySub _) (TVar a) = case M.lookup a tySub of
    Nothing -> TVar a
    Just t  -> t
  apply s (TFun p t1 t2) = TFun (apply s p) (apply s t1) (apply s t2)
  apply s (TPair p p1 p2) = TPair (apply s p) (apply s p1) (apply s p2)
  apply s (TList p l1) = TList (apply s p) (apply s l1)
  apply s t = t

instance Types TypeScheme where
  ftv (TypeScheme vars t) = ftv t `S.difference` (S.fromList vars)
  apply (SimpleSub tys anns) (TypeScheme vars t) = TypeScheme vars (apply (simpleTySub (foldr M.delete tys vars)) t)

instance Types TypeEnv where
  ftv (TypeEnv env) = ftv (M.elems env)
  apply s (TypeEnv env) = TypeEnv (M.map (apply s) env)

instance Types Annotation where
  ftv (AVar b) = S.singleton b
  ftv (Points p) = S.empty

  apply (SimpleSub _ annS) (AVar b) = case M.lookup b annS of
    Nothing -> (AVar b)
    Just b' -> (AVar b')

  apply _ b = b

instance Types Constraint where
  ftv (Constraint v ann) = S.singleton v

  apply s@(SimpleSub _ annS) c@(Constraint annV ann) = case M.lookup annV annS of
    Nothing -> Constraint annV (apply s ann)
    Just b -> Constraint b (apply s ann)

data TIEnv = TIEnv {}
data TIState = TIState { counter :: Int, bindings :: M.Map String Type }

type TI a = ExceptT String (StateT TIState IO) a

runTI :: TI a -> IO (Either String a, TIState)
runTI t = do
    (res, st) <- runStateT (runExceptT t) initTIState
    return (res, st)
  where
    initTIState = TIState { counter = 0, bindings = M.empty }

execTI :: TI a -> IO (Either String a)
execTI t = do
  (r, s) <- runTI t
  return r

newTyVar :: String -> TI Type
newTyVar prefix = do
  s <- get
  put s { counter = counter s + 1 }
  return (TVar (prefix ++ show (counter s)))

newAnnVar :: Pi -> TI AnnVar
newAnnVar prefix = do
  s <- get
  put s { counter = counter s + 1 }
  return $ prefix ++ show (counter s)

storeBinding :: String -> Type -> TI ()
storeBinding n ty = do
  s <- get
  put s { bindings = M.singleton n ty `M.union` (bindings s)}

showBindings :: SimpleSub -> Constraints -> TI ()
showBindings sub cs = do
  s <- get
  let bs = M.map (show . transform (solveConstraints cs) . apply sub) (bindings s)
  liftIO $ putStrLn "Bindings:"
  liftIO $ mapM_ (putStrLn . showBind) (M.toList bs)

  where
  showBind (n, ty) = n ++ " = " ++ ty

generalize :: TypeEnv -> Type -> TypeScheme
generalize env ty = TypeScheme newEnv ty
  where newEnv = S.toList (ftv ty `S.difference` ftv env)

instantiate :: TypeScheme -> TI Type
instantiate (TypeScheme vars ty) = do
  nvars <- mapM (\_ -> newTyVar "a") vars
  let s = simpleTySub $ M.fromList (zip vars nvars)
  return $ apply s ty

generalizeAnn :: AnnVar -> Type -> (Type, Constraints)
generalizeAnn b (TFun p2@(Points _) a r) = (TFun (AVar b) a r, [Constraint b p2])
generalizeAnn b t = (t, noConstraints)

unification :: Type -> Type -> TI (SimpleSub, Constraints)
unification TNat TNat = return (emptySubst, noConstraints)
unification TBool TBool = return (emptySubst, noConstraints)
unification (TFun (AVar b1) a1 r1) (TFun (AVar b2) a2 r2) = do
  (s1, c1) <- unification a1 a2
  (s2, c2) <- unification (apply s1 r1) (apply s1 r2)

  return $ (s1 <°> s2, c1 ++ c2)
unification f1@(TFun p1@(Points _) a1 r1) f2@(TFun (AVar b2) a2 r2) = do
  b <- newAnnVar "b"
  let c = Constraint b p1
  let c2 = Constraint b2 (AVar b)
  (s1, cs) <- unification (TFun (AVar b) a1 r1) f2
  return (s1, c:c2:cs)

unification (TVar a) ty = bindVar a ty
unification ty (TVar a) = bindVar a ty
unification (TPair (AVar b1) l1 r1) (TPair (AVar b2) l2 r2) = do
  let s0 = simpleAnnSub $ M.singleton b2 b1
  (s1, c1) <- unification (apply s0 l1) (apply s0 l2)
  (s2, c2) <- unification (apply (s0 <°> s1) r1) (apply (s0 <°> s1) r2)
  return (s0 <°> s1 <°> s2, c1 ++ c2)

unification l1@(TList (AVar b1) t1) l2@(TList p1@(AVar b2) t2) = do
  let s0 = simpleAnnSub $ M.singleton b2 b1
  (s1, c1) <- unification (apply s0 t1) (apply s0 t2)
  return (s0 <°> s1, c1)
unification a b = throwError $ "unification failed " ++ show a  ++ " with "++ show b

bindVar :: TyVar -> Type -> TI (SimpleSub, Constraints)
bindVar a t | TVar a == t = return $ (simpleTySub (M.singleton a t), noConstraints)
        | a `S.member` ftv t = throwError "Unification failed in chk" -- throwError $ "occur check fails: " ++ a ++ " vs. " ++ show t
        | otherwise = return $ (simpleTySub $ M.singleton a t, noConstraints)

inference :: TypeEnv -> Expr -> TI (Type, SimpleSub, Constraints)
inference _ (Integer i) = return (TNat, emptySubst, noConstraints)
inference _ (Bool b)    = return (TBool, emptySubst, noConstraints)
inference (TypeEnv env) (Var a) = case M.lookup a env of
  Nothing -> throwError $ "not bound " ++ a
  Just x -> do
    t <- instantiate x
    return (t, emptySubst, noConstraints)

inference env (Fn ann arg body) = do
  tv <- newTyVar "a"
  let TypeEnv freeEnv = remove env arg
  let newEnv = freeEnv `M.union` (M.singleton arg (TypeScheme [] tv))
  (ty, sub, c) <- inference (TypeEnv newEnv) body
  -- freshAnn <- newAnnVar "b"
  return (TFun (Points (S.singleton ann)) (apply sub tv) ty, sub, c)

inference env (Fun ann fName arg body) = do
  argTv <- newTyVar "a"
  retTv <- newTyVar "a"
  freshAnn <- newAnnVar "b"
  let TypeEnv freeEnv = remove (remove env arg) fName
  let newEnv = freeEnv `M.union` (M.singleton fName (TypeScheme [] (TFun (AVar freshAnn) argTv retTv))) `M.union` (M.singleton arg (TypeScheme [] argTv))
  (ty, sub1, c1) <- inference (TypeEnv newEnv) body
  (sub2, c2) <- unification ty (apply sub1 retTv)
  let subComp = sub1 <°> sub2
  let (AVar newAnnVar) = apply subComp (AVar freshAnn)
  let newConstraints = (Constraint newAnnVar (Points (S.singleton ann))):(apply sub2 c1) ++ c2
  return (TFun (AVar newAnnVar) (apply subComp argTv) (apply sub2 ty), subComp, newConstraints)

inference env (App f x) = do
  (t1, s1, c1) <- inference env f
  (t2, s2, c2) <- inference (apply s1 env) x
  tv <- newTyVar "a"
  freshAnn <- newAnnVar "b"

  (s3, c3) <- unification (apply s2 t1) (TFun (AVar freshAnn) t2 tv)
  let newConstraints = (apply (s2 <°> s3) c1) ++ (apply s3 c2) ++ c3
  return (apply s3 tv, s1 <°> s2 <°> s3, newConstraints)

inference env (ITE g t e) = do
  (t1, s1, c1) <- inference env g
  (t2, s2, c2) <- inference (apply s1 env) t
  (t3, s3, c3) <- inference (apply s2 (apply s1 env)) e
  (s4, c4) <- unification (apply s3 (apply s2 t1)) TBool
  b <- newAnnVar "b"
  let (t2', c5) = generalizeAnn b t2
  let (t3', c6) = generalizeAnn b t3
  (s5, c7) <- unification (apply s4 t3') (apply (s2 <°> s3) t2')
  let allComp = s1 <°> s2 <°> s3 <°> s4 <°> s5
  let newConstraints = apply (s2 <°> s3 <°> s4 <°> s5) c1 ++ apply (s3 <°> s4 <°> s5) c2 ++ apply (s4 <°> s5) c3 ++ apply s5 c4 ++ apply s5 c5 ++ apply s5 c6 ++ c7
  return ((apply s5 (apply s4 t3')), allComp, newConstraints)

inference env (Oper op e1 e2) = do
  (t1, s1, c1) <- inference env e1
  (t2, s2, c2) <- inference (apply s1 env) e2
  b <- newAnnVar "b"
  let (t1', c3) = generalizeAnn b t1
  let (t2', c4) = generalizeAnn b t2
  (s3, c5) <- unification (apply s2 t1') t2'
  let newConstraints = apply (s2 <°> s3 ) c1 ++ apply (s3 ) c2 ++ apply (s3) c3 ++ apply (s3) c4 ++ c5
  return (opTy op, s1 <°> s2 <°> s3 , newConstraints)

  where
    opTy Eq = TBool
    opTy _  = TNat

inference env (Let n e1 e2) = do
  (t1, s1, c1) <- inference env e1
  let TypeEnv freeEnv = remove env n
  let newEnv = TypeEnv (M.insert n (generalize (apply s1 env) t1) freeEnv)
  (t2, s2, c2) <- inference newEnv e2
  let newConstraints = (apply s2 c1) ++ c2
  storeBinding n t1
  return $ (t2, s1 <°> s2, newConstraints)

inference env (Pair ann e1 e2) = do
  (t1, s1, c1) <- inference env e1
  (t2, s2, c2) <- inference (apply s1 env) e2
  freshAnn <- newAnnVar "b"
  let newConstraints = (Constraint freshAnn $ Points $ S.singleton ann):(apply s2 c1) ++ c2
  return $ (TPair (AVar freshAnn) (apply s2 t1) t2, s1 <°> s2, newConstraints)

inference env (PCase e0 (l, r) e1) = do
  (t1, s1, c1) <- inference env e0
  lTv <- newTyVar "a"
  rTv <- newTyVar "a"
  let TypeEnv freeEnv = remove (remove env l) r
  let newEnv = freeEnv `M.union` (M.singleton l (TypeScheme [] lTv)) `M.union` (M.singleton r (TypeScheme [] rTv))
  (t2, s2, c2) <- inference (apply s1 (TypeEnv newEnv)) e1
  freshAnn <- newAnnVar "b"
  (s3, c3) <- unification (apply s2 t1) (TPair (AVar freshAnn) (apply s2 lTv) (apply s2 rTv))
  let newConstraints = apply (s2 <°> s3) c1 ++ apply s3 c2 ++ c3

  return $ (apply s3 t2, s1 <°> s2 <°> s3, newConstraints)

inference _ (Nil ann) = do
  tv <- newTyVar "a"
  freshAnn <- newAnnVar "b"
  return (TList (AVar freshAnn) tv, emptySubst, [Constraint freshAnn $ Points $ S.singleton ann])

inference env (Cons ann e1 e2) = do
  (t1, s1, c1) <- inference env e1
  (t2, s2, c2) <- inference (apply s1 env) e2
  freshAnn <- newAnnVar "b"
  (s3, c3) <- unification (apply s2 (TList (AVar freshAnn) t1)) t2
  let AVar newAnn = apply s3 (AVar freshAnn)
  let newConstraints = (Constraint newAnn $ Points $ S.singleton ann):(apply (s2 <°> s3) c1) ++ apply s3 c2 ++ c3
  return $ (TList (AVar freshAnn) t1, s1 <°> s2 <°> s3, newConstraints)

inference env (LCase e1 (h, t) e2 e3) = do
  (t1, s1, c1) <- inference env e1
  hTv <- newTyVar "a"
  tTv <- newTyVar "a"
  freshAnn <- newAnnVar "b"

  let TypeEnv freeEnv = remove (remove env h) t
  let newEnv = freeEnv `M.union` (M.singleton h (TypeScheme [] hTv)) `M.union` (M.singleton t (TypeScheme [] (TList (AVar freshAnn) tTv)))
  (t2, s2, c2) <- inference (apply s1 (TypeEnv newEnv)) e2
  (t3, s3, c3) <- inference (apply s2 env) e3
  let (t2', c6) = generalizeAnn freshAnn t2
  let (t3', c7) = generalizeAnn freshAnn t3
  (s4, c4) <- unification (apply s3 t2') t3'
  b' <- newAnnVar "b"
  (s5, c5) <- unification (apply (s2 <°> s3 <°> s4) t1) (TList (AVar b') (apply (s2 <°> s3 <°> s4) hTv))
  let newConstraints = apply (s2 <°> s3 <°> s4 <°> s5) c1 ++ apply (s3 <°> s4 <°> s5) c2 ++ apply (s4 <°> s5) c3 ++ apply s5 c4 ++ c5 ++ apply (s4 <°> s5) c6 ++ apply (s4 <°> s5) c7
  return (apply (s3 <°> s4 <°> s5) t2', s1 <°> s2 <°> s3 <°> s4 <°> s5, newConstraints)

remove :: TypeEnv -> TyVar -> TypeEnv
remove (TypeEnv env) var = TypeEnv (M.delete var env)

typeInference :: M.Map TyScVar TypeScheme -> Expr -> TI Type
typeInference env e = do
  (t, s, c) <- inference (TypeEnv env) e
  showBindings s (simplifyConstraints c)
  return $ transform (solveConstraints (simplifyConstraints c)) $ apply s t

inferTy :: Expr -> IO (Either String Type)
inferTy e = execTI $ typeInference M.empty e

instance Show Type where
  showsPrec _ x = shows (prType x )

prType :: Type -> PP.Doc
prType (TVar n) = PP.text n
prType TNat = PP.text "Nat"
prType TBool = PP.text "Bool"
prType (TFun ann t s) = (prParenType t PP.<+> PP.text "->" PP.<+> prType s) `withAnn` ann
prType (TPair ann l r) = PP.parens (prType l PP.<+> PP.text "," PP.<+> prType r) `withAnn` ann
prType (TList ann t) = PP.brackets (prType t) `withAnn` ann

prParenType :: Type -> PP.Doc
prParenType t = case t of
  TFun _ _ _ -> PP.parens (prType t)
  _ -> prType t

prAnn :: Annotation -> PP.Doc
prAnn (AVar b) = PP.text b
prAnn (Points ps) = PP.braces $ PP.hsep (map PP.text $ S.toList ps)

withAnn :: PP.Doc -> Annotation -> PP.Doc
withAnn ppTy ann = PP.parens ppTy PP.<> PP.text "_" PP.<> prAnn ann
