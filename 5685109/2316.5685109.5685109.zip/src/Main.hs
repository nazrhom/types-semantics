-- (C) 2013-14 Pepijn Kokke & Wout Elsinghorst
-- Modifications made Jurriaan Hage

import Ast
import Parsing
import AlgorithmW
import Instrumentation
import Data.Set (Set)
import Data.Map (Map)
import System.Environment (getArgs)

main :: IO ()
main = do
  fname:_ <- getArgs
  expr <- parse fname
  let iExpr = instrument expr
  putStrLn $ "Printing AST with annotations"
  putStrLn $ show iExpr

  tyExpr <- inferTy iExpr
  case tyExpr of
    Right expr -> do
      putStrLn "Inferred type for program:"
      putStrLn (show expr)
    Left e -> putStrLn $ "Error: " ++ show e

run :: String -> IO ()
run name = do
  p <- parse name
  putStrLn (show p)
  return ()

-- |Parse and label program
parse :: String -> IO Expr
parse programName = do
  let fileName = programName
  content <- readFile fileName
  return (parseExpr content)
