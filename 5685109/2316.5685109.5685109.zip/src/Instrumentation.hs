module Instrumentation where

import Ast
import Parsing
import Control.Monad.State
import Control.Lens.Plated
import AlgorithmW
import qualified Data.Set as S
import qualified Data.Map as M

instrument :: Expr -> Expr
instrument e = evalState (annotate e) 0
  where
    annotate e = transformM go e

    go (Fun p fnName argName body) = do
      i <- getAndIncr
      return $ Fun (p ++ (show i)) fnName argName body
    go (Fn p argName body) = do
      i <- getAndIncr
      return $ Fn (p ++ (show i)) argName body
    go (Pair p e1 e2) = do
      i <- getAndIncr
      return $ Pair (p ++ (show i)) e1 e2
    go (Nil p) = do
      i <- getAndIncr
      return $ Nil (p ++ (show i))
    go (Cons p e1 e2) = do
      i <- getAndIncr
      return $ Cons (p ++ (show i)) e1 e2
    go other = return other

    getAndIncr = do
      i <- get
      put (i + 1)
      return i
-- solveConstraints :: Constraints -> Type -> Type
-- solveConstraints c ty = rewrite (\t -> gatherPoints c t `mplus` (transitivity c t)) ty
--   where
--     gatherPoints :: Constraints -> Type -> Maybe Type
--     gatherPoints c (TFun (AVar b) e1 e2) = Just $ TFun varPoints e1 e2
--       where
--         varPoints = Points $ foldr gatherIfMatch S.empty c
--         gatherIfMatch :: Constraint -> S.Set Pi -> S.Set Pi
--         gatherIfMatch (Constraint var ann) acc | var == b = case ann of
--           AVar _ -> acc
--           Points ps -> ps `S.union` acc
--                                                | otherwise = acc
--     gatherPoints _ _ = Nothing
--
--     transitivity :: Constraints -> Type -> Maybe Type
--     transitivity c (TFun (AVar b) e1 e2) = Just
--       where
--         varPoints = Points $ foldr gatherIfMatch S.empty c
--         gatherIfMatch :: Constraint -> S.Set Pi -> S.Set Pi
--         gatherIfMatch (Constraint var ann) acc | var == b = case ann of
--           AVar _ -> acc
--           Points ps -> ps `S.union` acc
--                                                | otherwise = acc
