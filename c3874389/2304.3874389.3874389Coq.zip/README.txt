The file Basics.v contains all definitions and exercises from the first three
chapters of the book Software foundations.

In the bottom part of that file (at line 1152) you can find all the required exercises.

Made by:
Ferdinand van Walree, 3874389